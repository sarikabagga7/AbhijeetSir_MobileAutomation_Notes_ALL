package com.saucedemo.apps.runner;

import com.saucedemo.apps.controller.AppiumServiceManager;
import com.saucedemo.apps.utils.Constants;
import com.saucedemo.apps.utils.JsonUtils;
import com.saucedemo.apps.utils.PropertyUtils;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.*;

import java.io.IOException;

@CucumberOptions(
        features = "src/test/resources/features",
        glue = {"com.saucedemo.apps.glue",
                "com.saucedemo.apps.base"},
        plugin = {
                "pretty",
                "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm",
                "html:reports/cucumber.html",
                "json:reports/cucumber.json"
        },
        monochrome = true,
        tags = "@sanity"
)
public class TestRunner extends AbstractTestNGCucumberTests {
    @BeforeTest(alwaysRun = true)
    @Parameters({"profile", "port"})
    public void suiteSetup(@Optional String profileFromXml, @Optional String portFromXml) {
        try {
            loadTestConfiguration(profileFromXml);

            if (portFromXml != null) {
                Constants.get().APPIUM_SERVER_PORT = Integer.parseInt(portFromXml);
            }

            AppiumServiceManager.startAppiumService();
        } catch (Exception e) {
            System.out.println(String.format("************** Thread %s: Excpetion occurred during driver initialization: %s **************",
                    Thread.currentThread().getId(), e.getMessage()));
        }
    }

    @AfterTest(alwaysRun = true)
    public void suiteTeardown() {
        AppiumServiceManager.stopAppiumService();
    }

    private void loadTestConfiguration(String profilefromXML) throws IOException {
        PropertyUtils.loadConfigProperties();

        if (profilefromXML != null) {
            Constants.get().DEVICE_PROFILE = profilefromXML.trim();
        }

        JsonUtils.loadDeviceProfile(Constants.get().DEVICE_PROFILE);
    }
}
