package com.saucedemo.apps.glue;

import com.saucedemo.apps.controller.AppiumDriverManager;
import com.saucedemo.apps.pages.android.LoginPage_Android;
import com.saucedemo.apps.pages.interfaces.ILoginPage;
import com.saucedemo.apps.pages.ios.LoginPage_iOS;
import com.saucedemo.apps.utils.ScenarioContext;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;

import java.net.MalformedURLException;
import java.util.Map;

public class LoginSteps {
	private final ScenarioContext scenarioContext;

	private ILoginPage loginPage;
	private AppiumDriver driver;
	private Map<String, String> dataMap;

	public LoginSteps(ScenarioContext scenarioContext) {
		this.scenarioContext = scenarioContext;
		this.dataMap = (Map<String, String>) scenarioContext.get("DATA");
        try {
            this.driver = AppiumDriverManager.getDriver();
			if (this.driver instanceof AndroidDriver) {
				loginPage = new LoginPage_Android(driver);
			} else {
				loginPage = new LoginPage_iOS(driver);
			}
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
	}

	@Given("^User logs in with given credentials.$")
	public void login() {
		loginPage.login(dataMap.get("UserName"), dataMap.get("Password"));
	}

	@And("^User validates no error message displayed.$")
	public void validateNoErrorMessageDisplayed() {
		loginPage.validateNoErrorMessageDisplayed();
	}

	@And("^User validates error message \"(.+)\" displayed.$")
	public void validateErrorMessage(String expectedMsg) {
		loginPage.validateErrorMessage(expectedMsg);
	}
}
