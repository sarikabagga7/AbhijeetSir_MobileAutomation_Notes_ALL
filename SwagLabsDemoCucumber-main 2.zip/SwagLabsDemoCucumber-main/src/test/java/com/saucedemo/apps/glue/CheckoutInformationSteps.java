package com.saucedemo.apps.glue;

import com.saucedemo.apps.controller.AppiumDriverManager;
import com.saucedemo.apps.objects.User;
import com.saucedemo.apps.pages.android.CheckoutInformationPage_Android;
import com.saucedemo.apps.pages.interfaces.ICheckoutInformationPage;
import com.saucedemo.apps.pages.ios.CheckoutInformationPage_iOS;
import com.saucedemo.apps.utils.ScenarioContext;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.Then;

import java.net.MalformedURLException;
import java.util.Map;

public class CheckoutInformationSteps {
	private final ScenarioContext scenarioContext;

	private ICheckoutInformationPage checkoutInfoPage;
	private AppiumDriver driver;
	private Map<String, String> dataMap;
	
	public CheckoutInformationSteps(ScenarioContext scenarioContext) {
		this.scenarioContext = scenarioContext;
		this.dataMap = (Map<String, String>) scenarioContext.get("DATA");
		try {
			this.driver = AppiumDriverManager.getDriver();
			if (this.driver instanceof AndroidDriver) {
				checkoutInfoPage = new CheckoutInformationPage_Android(driver);
			} else {
				checkoutInfoPage = new CheckoutInformationPage_iOS(driver);
			}
		} catch (MalformedURLException e) {
			throw new RuntimeException(e);
		}
	}

	public void validateNavigationToCheckoutInfoPage() {
		checkoutInfoPage.validateNavigationToCheckoutInfoPage();
	}

	@Then("^User enters his details for checkout.$")
	public void setCheckoutInfo() {
		validateNavigationToCheckoutInfoPage();
		User user = new User(dataMap.get("FirstName"),
						     dataMap.get("LastName"),
							 dataMap.get("ZipCode"));
		checkoutInfoPage.setCheckoutInfo(user);
	}
}
