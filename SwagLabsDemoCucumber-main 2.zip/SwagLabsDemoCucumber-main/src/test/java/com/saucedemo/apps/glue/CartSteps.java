package com.saucedemo.apps.glue;

import com.saucedemo.apps.controller.AppiumDriverManager;
import com.saucedemo.apps.pages.android.CartPage_Android;
import com.saucedemo.apps.pages.interfaces.ICartPage;
import com.saucedemo.apps.pages.ios.CartPage_iOS;
import com.saucedemo.apps.utils.ScenarioContext;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.Then;

import java.net.MalformedURLException;
import java.util.Map;

public class CartSteps {
	private final ScenarioContext scenarioContext;

	private ICartPage cartPage;
	private AppiumDriver driver;
	private Map<String, String> dataMap;
	
	public CartSteps(ScenarioContext scenarioContext) {
		this.scenarioContext = scenarioContext;
		this.dataMap = (Map<String, String>) scenarioContext.get("DATA");

		try {
			this.driver = AppiumDriverManager.getDriver();

			if (this.driver instanceof AndroidDriver) {
				cartPage = new CartPage_Android(driver);
			} else {
				cartPage = new CartPage_iOS(driver);
			}
		} catch (MalformedURLException e) {
			throw new RuntimeException(e);
		}
	}

	public void validateNavigationToCartPage() {
		cartPage.validateNavigationToCartPage();
	}

	@Then("^User validates products? displayed on cart page.$")
	public void validateProductDisplayed() {
		validateNavigationToCartPage();
		String[] products = dataMap.get("ProductName").split("\\|");
		for (String product : products) {
			cartPage.validateProductDisplayed(product);
		}
	}

	@Then("^User clicks on checkout button.$")
	public void clickCheckoutButton() {
		cartPage.clickCheckoutButton();
	}

}
