package com.saucedemo.apps.pages.interfaces;

import com.saucedemo.apps.objects.User;

public interface ICheckoutInformationPage {
	public void validateNavigationToCheckoutInfoPage();
	public void setCheckoutInfo(User user);
}
