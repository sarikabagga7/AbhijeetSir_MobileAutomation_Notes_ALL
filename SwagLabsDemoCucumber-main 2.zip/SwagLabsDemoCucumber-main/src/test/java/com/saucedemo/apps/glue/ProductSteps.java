package com.saucedemo.apps.glue;

import com.saucedemo.apps.controller.AppiumDriverManager;
import com.saucedemo.apps.pages.android.ProductsPage_Android;
import com.saucedemo.apps.pages.interfaces.IProductsPage;
import com.saucedemo.apps.pages.ios.ProductsPage_iOS;
import com.saucedemo.apps.utils.ScenarioContext;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.Then;

import java.net.MalformedURLException;
import java.util.Map;

public class ProductSteps {
	private final ScenarioContext scenarioContext;

	private IProductsPage productsPage;
	private AppiumDriver driver;
	private Map<String, String> dataMap;
	
	public ProductSteps(ScenarioContext scenarioContext) {
		this.scenarioContext = scenarioContext;
		this.dataMap = (Map<String, String>) scenarioContext.get("DATA");

		try {
			this.driver = AppiumDriverManager.getDriver();
			if (this.driver instanceof AndroidDriver) {
				productsPage = new ProductsPage_Android(driver);
			} else {
				productsPage = new ProductsPage_iOS(driver);
			}
		} catch (MalformedURLException e) {
			throw new RuntimeException(e);
		}
	}


	public void validateNavigationToProductsPage() {
		productsPage.validateNavigationToProductsPage();
	}

	@Then("^User selects desired products? from Products Page.$")
	public void addproductToCart() {
		validateNavigationToProductsPage();
		String[] products = dataMap.get("ProductName").split("\\|");
		for (String product : products) {
			productsPage.addproductToCart(product);
		}

	}

	@Then("^User clicks on cart button.$")
	public void clickCartButton() {
		productsPage.clickCartButton();
	}
}
