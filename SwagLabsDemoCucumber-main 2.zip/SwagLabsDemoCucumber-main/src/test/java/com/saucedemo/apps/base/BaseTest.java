package com.saucedemo.apps.base;

import com.saucedemo.apps.controller.AppiumDriverManager;
import com.saucedemo.apps.utils.Constants;
import com.saucedemo.apps.utils.ReportUtils;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.cucumber.java.*;
import org.testng.Assert;

import java.net.MalformedURLException;

public class BaseTest {
    protected AppiumDriver driver = null;

    @Before
    public void scenarioSetUp() {
        try {
            driver = AppiumDriverManager.getDriver();
        } catch (MalformedURLException e) {
            Assert.fail("************** Exception while initializing drivers: " + e.getMessage() + " *****************");
        }
    }

    @BeforeStep
    public void stepSetup() {

    }

    @AfterStep
    public void stepTeardown() {
        ReportUtils.attachScreenshot();
    }

    @After
    public void scenarioTeardown(Scenario scenario) {
        try {
            if (scenario.isFailed())
                ReportUtils.attachScreenshot();
            terminateApp(driver);
            AppiumDriverManager.killDriver();
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    private void terminateApp(AppiumDriver driver) {
        if (!Constants.get().ENABLE_REMOTE) {
            if (driver instanceof AndroidDriver) {
                ((AndroidDriver) driver).terminateApp(Constants.get().PKGNAME);
            } else {
                ((IOSDriver) driver).terminateApp(Constants.get().BUNDLEID);
            }
        }
    }
}
