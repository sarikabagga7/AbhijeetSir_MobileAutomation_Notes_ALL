package com.saucedemo.apps.pages.android;

import com.saucedemo.apps.base.BasePage;
import com.saucedemo.apps.pages.interfaces.ICartPage;
import com.saucedemo.apps.utils.AndroidGestures;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import org.openqa.selenium.By;
import org.testng.Assert;

public class CartPage_Android extends BasePage implements AndroidGestures, ICartPage {
	private By yourCartBanner = AppiumBy.androidUIAutomator("new UiSelector().className(\"android.widget.TextView\").text(\"YOUR CART\")");
	private By scrollableCntr = AppiumBy.accessibilityId("test-Cart Content");
	private By checkoutBtn = AppiumBy.accessibilityId("test-CHECKOUT");

	private String productCard = "//android.widget.TextView[@text='%s']//ancestor::android.view.ViewGroup[@content-desc='test-Item']";


	public CartPage_Android(AppiumDriver driver) {
		super(driver);
	}
	
	@Override
	public void validateNavigationToCartPage() {
		Assert.assertTrue(isElementDisplayed(yourCartBanner), "User did not get navigated to Your Cart page.");
	}
	
	@Override
	public void validateProductDisplayed(String productName) {
		By locator = AppiumBy.xpath(String.format(productCard, productName));
		scrollGestureById(DRIVER, scrollableCntr, locator, "down");
		Assert.assertTrue(isElementDisplayed(locator), String.format("Product %s is not present in the Cart page.", productName));
	}
	
	@Override
	public void clickCheckoutButton() {
		scrollGestureById(DRIVER, scrollableCntr, checkoutBtn, "down");
		Assert.assertTrue(isElementClickable(checkoutBtn), "Checkout Button is not clickable.");
		clickGestureById(DRIVER, checkoutBtn);
	}

}
