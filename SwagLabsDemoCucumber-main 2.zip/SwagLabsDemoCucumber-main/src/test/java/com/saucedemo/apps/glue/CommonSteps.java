package com.saucedemo.apps.glue;

import com.saucedemo.apps.utils.ScenarioContext;
import com.saucedemo.apps.utils.TestDataUtils;
import io.cucumber.java.en.Given;
import org.testng.Assert;

public class CommonSteps {
    private final ScenarioContext scenarioContext;

    public CommonSteps(ScenarioContext scenarioContext) {
        this.scenarioContext = scenarioContext;
    }

    @Given("^System reads data from \"(.+)\" and sheet \"(.+)\" for \"(.+)\".$")
    public void readData(String fileName, String sheetName, String testCaseId) {
        try {
            scenarioContext.set("DATA",
                    TestDataUtils.getData(fileName, sheetName, testCaseId));

        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }
}
