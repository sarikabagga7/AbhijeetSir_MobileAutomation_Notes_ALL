package com.saucedemo.apps.utils;

import java.util.HashMap;
import java.util.Map;

public class ScenarioContext {
    private final Map<String, Object> data = new HashMap<>();

    public void set(String key, Object value) {
        data.put(key, value);
    }

    public <T> T get(String key, Class<T> clazz) {
        Object value = data.get(key);
        if (value == null) return null;
        try {
            return clazz.cast(value);
        } catch (ClassCastException e) {
            // Log the error and return null
            System.out.println(
                    "Type mismatch for key '" + key + "': " + e.getMessage()
            );
            return null;
        }
    }

    public Object get(String key) {
        return data.get(key);
    }
}
