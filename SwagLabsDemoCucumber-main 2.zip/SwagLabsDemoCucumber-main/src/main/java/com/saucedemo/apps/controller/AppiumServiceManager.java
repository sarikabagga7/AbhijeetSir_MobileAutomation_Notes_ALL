package com.saucedemo.apps.controller;

import com.saucedemo.apps.utils.Constants;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

import java.io.File;
import java.sql.SQLOutput;

public class AppiumServiceManager {
    // ThreadLocal to ensure each thread has its own Appium server
    private static final ThreadLocal<AppiumDriverLocalService> service =
            new ThreadLocal<>();

    private AppiumServiceManager() {}

    private static AppiumDriverLocalService buildService() {
        return new AppiumServiceBuilder()
                .withAppiumJS(new File(Constants.get().APPIUMJS_FILEPATH))
                .usingDriverExecutable(new File(Constants.get().NODE_FILEPATH))
                .withIPAddress(Constants.get().APPIUM_SERVER_ADDRESS)
                .usingPort(Constants.get().APPIUM_SERVER_PORT)
                .withArgument(() -> "--log-no-color")
                .build();
    }

    public static void startAppiumService() {
        if (Constants.get().ENABLE_REMOTE)
            return;
        if (service.get() == null) {
            AppiumDriverLocalService newService = buildService();
            service.set(newService);
        }

        AppiumDriverLocalService server = service.get();

        if (!server.isRunning()) {
            server.start();
            if (!server.isRunning()) {
                throw new RuntimeException("Failed to start Appium service on port: "
                        + Constants.get().APPIUM_SERVER_PORT);
            }
        } else {
            System.out.println("Appium service already running for this thread on port: "
                    + Constants.get().APPIUM_SERVER_PORT);
        }
    }

    public static void stopAppiumService() {
        if (Constants.get().ENABLE_REMOTE)
            return;
        AppiumDriverLocalService server = service.get();
        if (server == null) {
            System.out.println("Appium service was not initialized for this thread.");
            return;
        }
        if (server.isRunning()) {
            server.stop();
        }
        // Remove from ThreadLocal after stopping
        service.remove();
    }
}

