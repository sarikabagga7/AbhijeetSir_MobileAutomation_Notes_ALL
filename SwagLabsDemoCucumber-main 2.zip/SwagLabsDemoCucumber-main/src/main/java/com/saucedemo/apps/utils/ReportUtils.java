package com.saucedemo.apps.utils;

import com.saucedemo.apps.controller.AppiumDriverManager;
import io.appium.java_client.AppiumDriver;
import io.qameta.allure.Attachment;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.net.MalformedURLException;

public class ReportUtils {
    public static void attachScreenshot() {
        String screenshotName = "Screenshot_" + DateUtils.getTimestamp("yyyy_MM_dd_HH_mm_ss_SSS");
        attachScreenshot(screenshotName);
    }

    public static synchronized void attachScreenshot(String screenshotName) {
        AppiumDriver driver = null;
        try {
            driver = AppiumDriverManager.getDriver();
            if (driver == null) {
                throw new RuntimeException("Driver instance is null. Cannot capture screenshot.");
            }
            attachScreenshot(driver, screenshotName);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

    @Attachment(value = "{screenshotName}", type = "image/png")
    private static byte[] attachScreenshot(AppiumDriver driver, String screenshotName) {
        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
    }
}
