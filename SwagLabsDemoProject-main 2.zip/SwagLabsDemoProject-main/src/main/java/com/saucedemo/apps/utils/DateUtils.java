package com.saucedemo.apps.utils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public interface DateUtils {
    public static String getTimeStamp() {
        return getTimestamp("yyyy_MM_dd_HH_mm-ss_SSS");
    }

    public static String getTimestamp(String format) {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(format);
        return dtf.format(LocalDateTime.now());
    }
}
