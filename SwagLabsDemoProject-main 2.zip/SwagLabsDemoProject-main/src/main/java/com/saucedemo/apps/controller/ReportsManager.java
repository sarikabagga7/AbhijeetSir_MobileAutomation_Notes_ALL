package com.saucedemo.apps.controller;


import java.net.MalformedURLException;


import com.saucedemo.apps.utils.Constants;
import com.saucedemo.apps.utils.DateUtils;
import io.appium.java_client.AppiumDriver;
import io.qameta.allure.Attachment;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestListener;
import org.testng.ITestResult;


import java.net.MalformedURLException;

public class ReportsManager implements ITestListener {


    public void onTestFailure(ITestResult result) {
        String screenshotName = result.getMethod().getMethodName() + "_" + DateUtils.getTimeStamp();
        attachScreenshot(screenshotName);
        updateSaucelabsStatus(result);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        String screenshotName = result.getMethod().getMethodName() + "_" + DateUtils.getTimeStamp();
        attachScreenshot(screenshotName);
        updateSaucelabsStatus(result);
    }

    public static void attachScreenshot(String screenshotName)  {
        try {
            AppiumDriver driver = AppiumDriverManager.getDriver();
            attachScreenshot(driver, screenshotName);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

    @Attachment(value = "{screenshotName}", type = "image/png")
    private static byte[] attachScreenshot(AppiumDriver driver, String screenshotName){
        return  ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
    }

    private void updateSaucelabsStatus(ITestResult result) {
        try {
            if (Constants.get().ENABLE_REMOTE) {
                if (result.isSuccess()) {
                    AppiumDriverManager.getDriver().executeScript("sauce:job-result=passed");
                } else {
                    AppiumDriverManager.getDriver().executeScript("sauce:job-result=failed");
                }
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
