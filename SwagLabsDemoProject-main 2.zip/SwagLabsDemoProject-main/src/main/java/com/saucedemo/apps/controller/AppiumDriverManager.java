package com.saucedemo.apps.controller;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import com.saucedemo.apps.utils.Constants;
import com.saucedemo.apps.utils.PlatformType;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import org.openqa.selenium.MutableCapabilities;

public class AppiumDriverManager {
	private static final ThreadLocal<AppiumDriver> DRIVER = new ThreadLocal<>();

	public static AppiumDriver getDriver() throws MalformedURLException {
		return getDriver("");
	}

	public static AppiumDriver getDriver(String methodName) throws MalformedURLException {
		if (DRIVER.get() == null) {
			Constants.get().PLATFORM_TYPE = PlatformType.valueOf(Constants.getPlatformName().toUpperCase());
			DRIVER.set(getDriver(Constants.get().PLATFORM_TYPE, methodName));
		}
		return DRIVER.get();
	}

	public static void killDriver() {
		if (DRIVER.get() != null) {
			DRIVER.get().quit();
			DRIVER.remove();
		} else {
			throw new RuntimeException("Driver does not exist");
		}
	}

	private static AppiumDriver getDriver(PlatformType platformType, String methodName) throws MalformedURLException {
		AppiumDriver driver;
		String url = "http://" + Constants.get().APPIUM_SERVER_ADDRESS + ":" + Constants.get().APPIUM_SERVER_PORT;

		System.out.println("BROWSER: " + Constants.get().BROWSER);

		if (platformType == PlatformType.ANDROID) {
			driver = Constants.get().ENABLE_REMOTE ? getRemoteAndroidDriver(methodName) : getAndroidDriver(url);
		} else if (platformType == PlatformType.IOS) {
			driver = Constants.get().ENABLE_REMOTE ? getRemoteIOSDriver(methodName) : getIOSDriver(url);
		} else {
			throw new RuntimeException("Unsupported Platform Type");
		}
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		return driver;
	}
	
	public static String getBrowserSafe() {
	    String browser = Constants.get().BROWSER;
	    return (browser == null || browser.isEmpty()) ? "APP" : browser.toUpperCase();
	}

	private static AppiumDriver getAndroidDriver(String url) throws MalformedURLException {
		UiAutomator2Options options = new UiAutomator2Options();

		// === EMULATOR vs REAL DEVICE ===
	    if (Constants.getDeviceType().equalsIgnoreCase("emulator")) {
	        options.setAvd(Constants.getDeviceName()); 
	        options.setChromedriverExecutable(System.getProperty("user.dir") + Constants.get().ANDROID_CHOROMEDRIVER_EMULATOR_FILEPATH);
	        
	    } else if (Constants.getDeviceType().equalsIgnoreCase("real")) {
	        options.setDeviceName(Constants.getDeviceName()); // model name
	        //options.setUdid(Constants.get().DEVICE_UDID);   // unique device ID
	        options.setChromedriverExecutable(System.getProperty("user.dir") + Constants.get().ANDROID_CHOROMEDRIVER_REAL_FILEPATH);
	    }
		
	 // === BROWSER OR APP ===
	    switch (getBrowserSafe()) {
	        case "CHROME":
	            System.out.println("Running test on " +Constants.getDeviceType()+" Android mobile Chrome browser");
	            options.setCapability("browserName", "Chrome");
	            break;

	        case "FIREFOX":
	            System.out.println("Running test on Android mobile Firefox browser");
	            System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + Constants.get().GECKODRIVER_FILEPATH);
	            options.setCapability("browserName", "Firefox");
	            options.setCapability("moz:firefoxOptions", Map.of("androidPackage", "org.mozilla.firefox"));
	            break;

	        case "EDGE":
	            System.out.println("Running test on Android mobile Edge browser");
	            //System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + Constants.get().EDGEDRIVER_FILEPATH);
	            options.setCapability("browserName", "Edge");
	            options.setCapability("ms:edgeOptions", Map.of("androidPackage", "com.microsoft.emmx"));
	            break;

	        default:
	            // Native app
	            options.setApp(System.getProperty("user.dir") + "/src/test/resources/apps/" + Constants.get().APK_FILENAME);
	            options.setAppPackage(Constants.get().PKGNAME);
	            options.setAppActivity(Constants.get().ACTIVITY);
	    }      
		AppiumDriver driver = new AndroidDriver(new URL(url), options);
		return driver;
	}

	private static AppiumDriver getIOSDriver(String url) throws MalformedURLException {
		XCUITestOptions options = new XCUITestOptions();
		options.setDeviceName(Constants.getDeviceName());
		if ("SAFARI".equalsIgnoreCase(Constants.get().BROWSER)) {
			System.out.println("Running test on IOS mobile Safari browser");
			options.setCapability("browserName", "Safari");
		} else {
			options.setPlatformVersion(Constants.getPlatformVersion());
			options.setApp(System.getProperty("user.dir") + "/src/test/resources/apps/" + Constants.get().APP_FILENAME);
			options.setBundleId(Constants.get().BUNDLEID);
		}
		AppiumDriver driver = new IOSDriver(new URL(url), options);
		return driver;
	}

	private static AppiumDriver getRemoteAndroidDriver(String methodName) throws MalformedURLException {
		//Device Capabilities
		MutableCapabilities capabilities = new MutableCapabilities();
		capabilities.setCapability("platformName", Constants.getPlatformName());
		capabilities.setCapability("appium:platformVersion", Constants.getPlatformVersion());
		capabilities.setCapability("appium:deviceName", Constants.getDeviceName());
		capabilities.setCapability("appium:automationName", Constants.getAutomationName());
		capabilities.setCapability("appium:app", "storage:filename=" + Constants.get().APK_FILENAME);
		capabilities.setCapability("appium:noReset", Constants.getNoResetValue()); //Every time you run the test, clear all saved data — like login info, settings, cache — and start the app brand new.
		capabilities.setCapability("appium:appWaitActivity", "com.swaglabsmobileapp.*"); //Wait until an activity (screen) from the app appears.
		capabilities.setCapability("appium:appWaitDuration", 10000); //Wait up to 10 seconds for the app to open before giving up.
		// Sauce options
		HashMap<String, Object> sauceOptions = new HashMap<String, Object>();
		sauceOptions.put("username", Constants.get().REMOTE_USERNAME);
		sauceOptions.put("accessKey", Constants.get().REMOTE_ACCESSKEY);
		sauceOptions.put("build", "swaglabs_automated_tests");
		sauceOptions.put("name", Constants.getPlatformName().toLowerCase() + "-" + Constants.getDeviceName().toLowerCase().replace(" ", "_") + "_" + methodName);
		if (Constants.getDeviceType().equals("real"))
			sauceOptions.put("appiumVersion", "latest");

		capabilities.setCapability("sauce:options", sauceOptions);

		AppiumDriver driver = new AndroidDriver(new URL(Constants.get().REMOTE_URL), capabilities);
		return driver;
	}

	private static AppiumDriver getRemoteIOSDriver(String methodName) throws MalformedURLException {
		//Device Capabilities
		MutableCapabilities capabilities = new MutableCapabilities();
		capabilities.setCapability("platformName", Constants.getPlatformName());
		capabilities.setCapability("appium:platformVersion", Constants.getPlatformVersion());
		capabilities.setCapability("appium:deviceName", Constants.getDeviceName());
		capabilities.setCapability("appium:automationName", Constants.getAutomationName());
		capabilities.setCapability("appium:app", "storage:filename=" + Constants.get().APP_FILENAME);
		capabilities.setCapability("appium:noReset", Constants.getNoResetValue()); //Every time you run the test, clear all saved data — like login info, settings, cache — and start the app brand new.
		capabilities.setCapability("appium:wdaLaunchTimeout", 60000); //Give WDA up to 60 seconds to start before failing.
		capabilities.setCapability("appium:wdaConnectionTimeout", 60000); //Once WDA is running, wait up to 60 seconds to connect to it.
		capabilities.setCapability("appium:wdaStartupRetries", 3); //If WDA fails, try again up to 3 times.
		capabilities.setCapability("appium:wdaStartupRetryInterval", 10000); //Wait 10 seconds before retrying WDA startup.

		// Sauce options
		HashMap<String, Object> sauceOptions = new HashMap<String, Object>();
		sauceOptions.put("username", Constants.get().REMOTE_USERNAME);
		sauceOptions.put("accessKey", Constants.get().REMOTE_ACCESSKEY);
		sauceOptions.put("build", "swaglabs_automated_tests");
		sauceOptions.put("name", Constants.getPlatformName().toLowerCase() + "-" + Constants.getDeviceName().toLowerCase().replace(" ", "_") + "_" + methodName);
		if (Constants.getDeviceType().equals("real"))
			sauceOptions.put("appiumVersion", "latest");

		capabilities.setCapability("sauce:options", sauceOptions);

		AppiumDriver driver = new IOSDriver(new URL(Constants.get().REMOTE_URL), capabilities);
		return driver;
	}
}
