package com.saucedemo.apps.base;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.saucedemo.apps.controller.AppiumDriverManager;
import com.saucedemo.apps.controller.AppiumServiceManager;
import com.saucedemo.apps.controller.ReportsManager;
import com.saucedemo.apps.utils.Constants;
import com.saucedemo.apps.utils.JsonUtils;
import com.saucedemo.apps.utils.PlatformType;
import com.saucedemo.apps.utils.PropertyUtils;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.appmanagement.ApplicationState;
import io.appium.java_client.ios.IOSDriver;
import io.qameta.allure.testng.AllureTestNg;

@Listeners({AllureTestNg.class, ReportsManager.class})
public abstract class BaseTest {

	@BeforeTest(alwaysRun = true)
	@Parameters({ "profile", "port", "browser" })
	public void suiteSetup(@Optional String profile, @Optional String port, @Optional String browser) {
		try {
		    Reporter.log("===== @BeforeTest ====="+port, true);
			loadTestConfiguration(profile, port, browser);
			if (!Constants.get().ENABLE_REMOTE)
				AppiumServiceManager.startAppiumService();

		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	@BeforeMethod(alwaysRun = true)
	public void testSetup(Method method) {
	    Reporter.log("===== @BeforeMethod =====", true);
		try {
			AppiumDriverManager.getDriver(method.getName().toLowerCase());
		} catch (Exception e) {
			Assert.fail(e.getMessage());
		}
	}

	@AfterMethod(alwaysRun = true)
	public void testTeardown() {
		if (!Constants.get().ENABLE_REMOTE)
			terminateApp();
		AppiumDriverManager.killDriver();
		Reporter.log("App terminating", true);
	}

	@AfterTest(alwaysRun = true)
	public void suiteTeardown() {
		if (!Constants.get().ENABLE_REMOTE)
			AppiumServiceManager.stopAppiumService();
	}

	private void terminateApp() {
		try {
			if (Constants.get().PLATFORM_TYPE == PlatformType.ANDROID) {
				if ("CHROME".equalsIgnoreCase(Constants.get().BROWSER)) {
				} else {
					AndroidDriver driver = (AndroidDriver) AppiumDriverManager.getDriver();
					if (driver.queryAppState(Constants.get().PKGNAME) != ApplicationState.NOT_RUNNING) {
						driver.terminateApp(Constants.get().PKGNAME);
					}
					uninstallApp();
				}
			} else {
				System.out.println("Running test on iOS app");
				IOSDriver driver = (IOSDriver) AppiumDriverManager.getDriver();
				if (driver.queryAppState(Constants.get().BUNDLEID) != ApplicationState.NOT_RUNNING) {
					driver.terminateApp(Constants.get().BUNDLEID);
				}
				uninstallApp();
			}

		} catch (RuntimeException | MalformedURLException e) {
			throw new RuntimeException(e);
		}
	}

	private void uninstallApp() {
		System.out.println("uninstalling....... method called ");
		try {
			if (Constants.get().PLATFORM_TYPE == PlatformType.ANDROID) {
				System.out.println("Uninstalling Android app: " + Constants.get().PKGNAME);
				((AndroidDriver) AppiumDriverManager.getDriver()).removeApp(Constants.get().PKGNAME);
			} else {
				System.out.println("Uninstalling iOS app: " + Constants.get().BUNDLEID);
				((IOSDriver) AppiumDriverManager.getDriver()).removeApp(Constants.get().BUNDLEID);
			}
		} catch (Exception e) {
			System.out.println("Uninstall failed: " + e.getMessage());
		}
	}

	private void loadTestConfiguration(String profileFromXml, String portFromXml, String browserFromXml)
			throws IOException {
		PropertyUtils.loadConfigProperties();
		if (profileFromXml != null) {
			try {
				Constants.get().DEVICE_PROFILE = profileFromXml;
			} catch (Exception ex) {
				System.out.println(ex.getMessage());
				ex.printStackTrace();
			}
		}
		if (portFromXml != null ) {
		    Constants.get().APPIUM_SERVER_PORT = Integer.parseInt(portFromXml);
		}
		if (browserFromXml != null) {
			Constants.get().BROWSER = browserFromXml;
		}
		JsonUtils.loadDeviceProfile(Constants.get().DEVICE_PROFILE);
	}
}
