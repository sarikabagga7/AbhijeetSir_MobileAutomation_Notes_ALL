package com.saucedemo.browser.test;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.saucedemo.apps.base.BaseTest;
import com.saucedemo.apps.controller.AppiumDriverManager;
import com.saucedemo.browser.pages.LoginPage_Browser;

public class LoginTest extends BaseTest {
	@Test
	public void loginTest() {
		   try {
	    LoginPage_Browser loginPage = new LoginPage_Browser(AppiumDriverManager.getDriver());

	    loginPage.login("standard_user", "secret_sauce");
	}
	  catch (Exception e) {
         Assert.fail("Exception occurred: " + e.getMessage());
     }
}

}