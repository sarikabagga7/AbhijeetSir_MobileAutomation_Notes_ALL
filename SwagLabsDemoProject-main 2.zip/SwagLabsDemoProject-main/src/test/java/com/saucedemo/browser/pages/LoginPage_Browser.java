package com.saucedemo.browser.pages;

import com.saucedemo.apps.base.BasePage;
import com.saucedemo.apps.pages.interfaces.ILoginPage;
import com.saucedemo.apps.utils.AndroidGestures;
import com.saucedemo.apps.utils.Constants;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import java.time.Duration;
import java.util.Set;

public class LoginPage_Browser extends BasePage implements ILoginPage  {
   
	private By userName =By.id("user-name");
    private By password = By.id("password");
    private By loginBtn = By.id("login-button");

    
    public LoginPage_Browser(AppiumDriver driver) {
        super(driver);
    }

    @Override
    public void login(String userName, String password) {
    	//DRIVER.get("https://www.saucedemo.com/");
     
    	DRIVER.get(Constants.get().URL);
        addDelay(5); 
        System.out.println("Current context (before switch): " + ((AndroidDriver) DRIVER).getContext());
    	enterText(this.userName, userName);
    	enterText(this.password, password);
    	click(this.loginBtn);
		
		System.out.println("Title: " + DRIVER.getTitle());
    }

    @Override
    public void validateErrorMessage(String expectedMsg) {
        
    	System.out.println("Not implemnetd yet");
    }

    @Override
    public void validateNoErrorMessageDisplayed() {
    	System.out.println("Not implemnetd yet");
    }
}
