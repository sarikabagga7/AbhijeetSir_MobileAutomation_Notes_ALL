package com.saucedemo.apps.test;

import com.saucedemo.apps.base.BaseTest;
import com.saucedemo.apps.controller.AppiumDriverManager;
import com.saucedemo.apps.pages.LoginPage;
import com.saucedemo.apps.pages.ProductsPage;
import com.saucedemo.apps.utils.RetryUtils;
import io.appium.java_client.AppiumDriver;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import org.testng.Assert;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import org.testng.annotations.Test;

@Epic("Login Functionality")
@Feature("Validate login functionality of the mobile app")
public class LoginTests extends BaseTest {
    @Test(description = "[Login-001] Verify user is able to login using valid credentials.",
            groups = {"sanity", "regression"},
            retryAnalyzer = RetryUtils.class)
    @Description("Verify user is able to login using valid credentials.")
    public void loginUsingValidCredentials() {
        try {
            AppiumDriver driver = AppiumDriverManager.getDriver();
            //Login
            LoginPage loginPage = new LoginPage(driver);
            loginPage.login("standard_user", "secret_sauce");
            loginPage.validateNoErrorMessageDisplayed();
            //Validate login
            ProductsPage productPage = new ProductsPage(driver);
            productPage.validateNavigationToProductsPage();
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Error: " + e.getMessage());
        }
    }


    @Test(description = "[Login-002] Verify user is not able to login using locked out credentials.",
            groups = {"regression","sanity"},
            retryAnalyzer = RetryUtils.class)
    @Description("Verify user is not able to login using locked out credentials.")
    public void loginUsingLockedoutCredentials() {
        try {
            AppiumDriver driver = AppiumDriverManager.getDriver();
            //Login
            LoginPage loginPage = new LoginPage(driver);
            loginPage.login("locked_out_user", "secret_sauce");
            //Validate login
            loginPage.validateErrorMessage("Sorry, this user has been locked out.");
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Error: " + e.getMessage());
        }
    }
}
