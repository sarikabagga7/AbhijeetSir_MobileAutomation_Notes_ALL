package com.saucedemo.apps.pages;

import com.saucedemo.apps.pages.android.ProductsPage_Android;
import com.saucedemo.apps.pages.interfaces.IProductsPage;
import com.saucedemo.apps.pages.ios.ProductsPage_IOS;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.qameta.allure.Step;

public class ProductsPage {
    private IProductsPage productsPage;
    private AppiumDriver driver;

    public ProductsPage(AppiumDriver driver) {
        this.driver = driver;
        if (this.driver instanceof AndroidDriver) {
            productsPage = new ProductsPage_Android(driver);
        } else {
            productsPage = new ProductsPage_IOS(driver);
        }
    }

    @Step("User navigate to Products Page")
    public void validateNavigationToProductsPage() {
        productsPage.validateNavigationToProductsPage();
    }
    
    @Step
    ("User adds product {0} to cart.")

    public void addproductToCart(String productName) {
        productsPage.addproductToCart(productName);
    }

    @Step("User clicks on cart button.")
    public void clickCartButton() {
        productsPage.clickCartButton();
    }
}
