package com.saucedemo.apps.utils;

import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

import java.util.HashMap;
import java.util.Map;

public class TestDataUtils {
    public static Map<String, String> getData(String fileName, String sheetName, String testcaseId) {
        Map<String, String> data = new HashMap<>();
        Connection connection = null;
        Recordset recordset = null;
        try {
            Fillo fillo = new Fillo();
            connection = fillo.getConnection(
                    System.getProperty("user.dir") + "/src/test/resources/data/" + fileName);
            String query = String.format("SELECT * FROM %s WHERE TestCaseID='%s'", sheetName, testcaseId);
            recordset = connection.executeQuery(query);

            if (recordset.next()) {
                for (String colName : recordset.getFieldNames()) {
                    data.put(colName.trim(), recordset.getField(colName).trim());
                }
            }

        } catch (Exception e) {
            throw new RuntimeException(
                    "Excpetion during reading data for testcase id: " + testcaseId + ": " + e.getMessage());
        } finally {
            if (connection != null) connection.close();
            if (recordset != null) recordset.close();
        }
        return data;
    }
}
