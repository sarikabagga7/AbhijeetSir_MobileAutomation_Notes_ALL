package demo.ios;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
/*
 * for IOS Predicate Strings
 */
public class DragGestureDemo {
    static String bundleId = "org.wdioNativeDemoApp";

    public static void main(String[] args) {
        AppiumDriverLocalService service = new AppiumServiceBuilder()
                .withAppiumJS(new File("/opt/homebrew/lib/node_modules/appium/build/lib/main.js"))
                .usingDriverExecutable(new File("/opt/homebrew/bin/node"))
                .withIPAddress("127.0.0.1").usingPort(4723).build();
        try {
            //Step 1: launch appium service
            service.start();

            //Step 2: launch appium driver and connect with emulator
            AppiumDriver driver = getDriver();
            //Step 3: launch app
            startApp(driver);
            
            clickGestureByCoords(driver, AppiumBy.accessibilityId("Drag"));
        
            drag(driver, AppiumBy.accessibilityId("drag-l1"), AppiumBy.accessibilityId("drop-l1"));
            drag(driver, AppiumBy.accessibilityId("drag-c1"), AppiumBy.accessibilityId("drop-c1"));
            drag(driver, AppiumBy.accessibilityId("drag-r1"), AppiumBy.accessibilityId("drop-r1"));
            drag(driver, AppiumBy.accessibilityId("drag-l2"), AppiumBy.accessibilityId("drop-l2"));
            drag(driver, AppiumBy.accessibilityId("drag-c2"), AppiumBy.accessibilityId("drop-c2"));
            drag(driver, AppiumBy.accessibilityId("drag-r2"), AppiumBy.accessibilityId("drop-r2"));
            drag(driver, AppiumBy.accessibilityId("drag-l3"), AppiumBy.accessibilityId("drop-l3"));
            drag(driver, AppiumBy.accessibilityId("drag-c3"), AppiumBy.accessibilityId("drop-c3"));
            drag(driver, AppiumBy.accessibilityId("drag-r3"), AppiumBy.accessibilityId("drop-r3"));
            
            if (isElementDisplayed(driver, AppiumBy.iOSNsPredicateString("label == 'Congratulations'"))) {
            	System.out.println("Success");
            } else {
            	System.out.println("Failed");
            }
            
            Thread.sleep(5000);

            terminateApp(driver);
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            service.stop();
        }
    }

    public static AppiumDriver getDriver() throws MalformedURLException {
        XCUITestOptions options = new XCUITestOptions();
        //options.setUdid("8F027E83-A5B4-400C-AD0D-47B9AB8226D2");
        options.setDeviceName("iPhone 15");
        options.setPlatformVersion("17.0");
        //options.setApp(System.getProperty("user.dir") + "/src/test/resources/UIKitCatalog.app");

        AppiumDriver driver = new IOSDriver(new URL("http://127.0.0.1:4723"), options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

        return driver;
    }

    public static void startApp(AppiumDriver driver) {
        HashMap<String, Object> params = new HashMap<>();
        params.put("bundleId", bundleId);
        driver.executeScript("mobile: launchApp", params);
    }

    public static void terminateApp(AppiumDriver driver) {
        ((IOSDriver) driver).terminateApp(bundleId);
    }

    public static void click(AppiumDriver driver, By locator) {
        driver.findElement(locator).click();
    }

    public static void setText(AppiumDriver driver, By locator, String text) {
        driver.findElement(locator).sendKeys(text);
    }

    public static void setText(AppiumDriver driver, By locator, Keys key) {
        driver.findElement(locator).sendKeys(key);
    }
    
    public static void clickGestureByCoords(AppiumDriver driver, By locator) {
        WebElement element = driver.findElement(locator);
        int startX = element.getLocation().getX();
        int startY = element.getLocation().getY();

        int centerX = startX + element.getSize().getWidth()/2;
        int centerY = startY + element.getSize().getHeight()/2;

        HashMap<String, Object> params = new HashMap<>();
        params.put("x", centerX);
        params.put("y", centerY);
        driver.executeScript("mobile: tap", params);
    }	
    
    public static void scrollToElement(AppiumDriver driver, By scrollableCntrLocator, By targetLocator) {
        HashMap<String, Object> params = new HashMap<>();
        params.put("element", ((RemoteWebElement)driver.findElement(scrollableCntrLocator)).getId());
        params.put("direction", "down");

        while (!isElementDisplayed(driver, targetLocator)) {
            driver.executeScript("mobile: scroll", params);
        }
    }
    
    public static void scrollUsingPredicateString(AppiumDriver driver, By scrollableCntrLocator, String targetPredicateString) {
        HashMap<String, Object> params = new HashMap<>();
        params.put("element", ((RemoteWebElement)driver.findElement(scrollableCntrLocator)).getId());
        params.put("predicateString", targetPredicateString);

        driver.executeScript("mobile: scroll", params);
    }
    
    public static void scrollUsingAccessibiltyId(AppiumDriver driver, By scrollableCntrLocator, String targetName) {
        HashMap<String, Object> params = new HashMap<>();
        params.put("element", ((RemoteWebElement)driver.findElement(scrollableCntrLocator)).getId());
        params.put("name", targetName);

        driver.executeScript("mobile: scroll", params);
    }
    
    public static void swipeToBeginning(AppiumDriver driver, By scrollableCntrLocator) {
        HashMap<String, Object> params = new HashMap<>();
        params.put("element", ((RemoteWebElement)driver.findElement(scrollableCntrLocator)).getId());
        params.put("direction", "down");

        driver.executeScript("mobile: swipe", params);
    }
    
    public static void swipeToEnd(AppiumDriver driver, By scrollableCntrLocator) {
        HashMap<String, Object> params = new HashMap<>();
        params.put("element", ((RemoteWebElement)driver.findElement(scrollableCntrLocator)).getId());
        params.put("direction", "up");

        driver.executeScript("mobile: swipe", params);
    }
    
    public static boolean isElementDisplayed(AppiumDriver driver, By targetLocator) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
            wait.until(ExpectedConditions.visibilityOfElementLocated(targetLocator));
            return true;
        } catch (TimeoutException | NoSuchElementException e) {
            return false;
        }
    }
    
    public static void drag(AppiumDriver driver, By srcLocator, By destLocator) {
    	WebElement src = driver.findElement(srcLocator);
        WebElement destn = driver.findElement(destLocator);
        
        int fromX = src.getLocation().getX() + src.getSize().width/2;
        int fromY = src.getLocation().getY() + src.getSize().height/2;
        
        int toX = destn.getLocation().getX() + destn.getSize().width/2;
        int toY = destn.getLocation().getY() + destn.getSize().height/2;
        
        HashMap<String, Object> params = new HashMap<>();
        params.put("fromX", fromX);
        params.put("fromY", fromY);
        params.put("toX", toX);
        params.put("toY", toY);
        params.put("duration", 6.0);
        
        driver.executeScript("mobile: dragFromToForDuration", params);
    }
}
