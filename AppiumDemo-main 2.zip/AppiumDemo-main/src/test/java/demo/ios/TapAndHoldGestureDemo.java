package demo.ios;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class TapAndHoldGestureDemo {
	
	public static String bundleid = "com.example.apple-samplecode.UICatalog";

	public static void main(String[] args) {
		AppiumDriverLocalService service = new AppiumServiceBuilder()
				.withAppiumJS(new File("/opt/homebrew/lib/node_modules/appium/build/lib/main.js"))
				.usingDriverExecutable(new File("/opt/homebrew/bin/node"))
				.withIPAddress("127.0.0.1")
				.usingPort(4723)
				.build();
		try {
			service.start();
			
			AppiumDriver driver = getDriver();
			
			launchApp(driver);
			
		    click(driver, AppiumBy.iOSNsPredicateString("name == 'Steppers'"));
		    
		    tapAndHold(driver, AppiumBy.xpath("//XCUIElementTypeOther[@name='DEFAULT']//following-sibling::XCUIElementTypeCell[1]//XCUIElementTypeButton[@name='Increment']"), 4.0f);
		    
		    
		    WebElement element = driver.findElement(
		    		AppiumBy.xpath("//XCUIElementTypeOther[@name='TINTED']//following-sibling::XCUIElementTypeCell[1]//XCUIElementTypeButton[@name='Increment']"));
		    HashMap<String, Object> params = new HashMap<String, Object>();
		    params.put("elementId", ((RemoteWebElement) element).getId());

		    driver.executeScript("mobile: doubleTap", params);
		    Thread.sleep(2000);
		    driver.executeScript("mobile: doubleTap", params);
		    
		    
		    Thread.sleep(5000);
		    
		    click(driver, 
		    		AppiumBy.xpath("//XCUIElementTypeNavigationBar/XCUIElementTypeButton[@name='UIKitCatalog']"));
		    
		    Thread.sleep(5000);
			
		    terminateApp(driver);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			service.stop();
		}
	}
	
	public static AppiumDriver getDriver() throws MalformedURLException {
		XCUITestOptions options = new XCUITestOptions();
		options.setDeviceName("iPhone 15");
		options.setPlatformVersion("17.0");
		
		AppiumDriver driver = new IOSDriver(new URL("http://127.0.0.1:4723"), options);
		return driver;
	}
	
	public static void launchApp(AppiumDriver driver) {
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("bundleId", bundleid);
	    driver.executeScript("mobile: launchApp", params);
	}
	
	public static void terminateApp(AppiumDriver driver) {
		((IOSDriver) driver).terminateApp(bundleid);
	}
	
	public static void click(AppiumDriver driver, By locator) {
		driver.findElement(locator).click();
	}
	
	public static void enterText(AppiumDriver driver, By locator, String text) {
		driver.findElement(locator).sendKeys(text);
	}
	
	public static String getAttribute(AppiumDriver driver, By locator, String attributeName) {
		return driver.findElement(locator).getAttribute(attributeName);
	}
	
	public static void pickerWheelGesture(AppiumDriver driver, By locator, int targetValue, float offset) {
		WebElement wheel = driver.findElement(locator);

	    HashMap<String, Object> params = new HashMap<>();
	    params.put("elementId", ((RemoteWebElement) wheel).getId());
	    params.put("offset", 0.1);
	    if (Integer.parseInt(wheel.getAttribute("value")) > targetValue) {
	    	params.put("order", "previous");
	    } else {
	    	params.put("order", "next");
	    }
	    
	    while (Integer.parseInt(wheel.getAttribute("value")) != targetValue) {
	    	driver.executeScript("mobile: selectPickerWheelValue", params);
	    }
	}
	
	public static void tapAndHold(AppiumDriver driver, By locator, float duration) {
		WebElement element = driver.findElement(locator);
	    
	    HashMap<String, Object> params = new HashMap<String, Object>();
	    params.put("elementId", ((RemoteWebElement) element).getId());
	    params.put("duration", duration);

	    driver.executeScript("mobile: touchAndHold", params);
	}

}
