package demo.ios;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import org.openqa.selenium.MutableCapabilities;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;

public class SaucelabsAppDemo {
    public static void main(String[] args) throws MalformedURLException {
        AppiumDriver driver = null;
        try {
            MutableCapabilities capabilities = launchInRealDevice();

            driver = new IOSDriver(new URL("https://ondemand.eu-central-1.saucelabs.com:443/wd/hub"), capabilities);
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

            driver.findElement(AppiumBy.accessibilityId("test-Username")).sendKeys("standard_user");
            driver.findElement(AppiumBy.accessibilityId("test-Password")).sendKeys("secret_sauce");
            driver.findElement(AppiumBy.accessibilityId("test-LOGIN")).click();

            Thread.sleep(5000);

            driver.executeScript("sauce:job-result=passed");
        } catch (Exception e) {
            e.printStackTrace();
            driver.executeScript("sauce:job-result=failed");
        } finally {
            if (driver != null)
                driver.quit();
        }

    }

    private static MutableCapabilities launchInSimulator() {
        MutableCapabilities capabilities = new MutableCapabilities();
        capabilities.setCapability("platformName", "ios");
        capabilities.setCapability("appium:platformVersion", "17.0");
        capabilities.setCapability("appium:deviceName", "iPhone 15 Plus Simulator");
        capabilities.setCapability("appium:automationName", "XCUITest");
        capabilities.setCapability("appium:app", "storage:filename=SwagLabsMobileAppSim.zip");

        capabilities.setCapability("appium:wdaLaunchTimeout", 60000);
        capabilities.setCapability("appium:wdaConnectionTimeout", 60000);
        capabilities.setCapability("appium:wdaStartupRetries", 3);
        capabilities.setCapability("appium:wdaStartupRetryInterval", 10000);
        capabilities.setCapability("appium:noReset", false);

        // Sauce options
        HashMap<String, Object> sauceOptions = new HashMap<String, Object>();
        sauceOptions.put("username", "");
        sauceOptions.put("accessKey", "");
        sauceOptions.put("build", "Appium-Saucelabs Demo");
        sauceOptions.put("name", "for simulator");

        capabilities.setCapability("sauce:options", sauceOptions);

        return capabilities;
    }

    private static MutableCapabilities launchInRealDevice() {
        MutableCapabilities capabilities = new MutableCapabilities();
        capabilities.setCapability("platformName", "ios");
        capabilities.setCapability("appium:platformVersion", "18.7.2");
        capabilities.setCapability("appium:deviceName", "iPhone 15");
        capabilities.setCapability("appium:automationName", "XCUITest");
        capabilities.setCapability("appium:app", "storage:filename=SauceLabs-Demo-App-With-TestFairy.ipa");

        capabilities.setCapability("appium:wdaLaunchTimeout", 60000);
        capabilities.setCapability("appium:wdaConnectionTimeout", 60000);
        capabilities.setCapability("appium:wdaStartupRetries", 3);
        capabilities.setCapability("appium:wdaStartupRetryInterval", 10000);
        capabilities.setCapability("appium:noReset", false);

        // Sauce options
        HashMap<String, Object> sauceOptions = new HashMap<String, Object>();
        sauceOptions.put("username", "");
        sauceOptions.put("accessKey", "");
        sauceOptions.put("build", "Appium-Saucelabs Demo");
        sauceOptions.put("name", "for iphone");
        sauceOptions.put("appiumVersion", "latest");

        capabilities.setCapability("sauce:options", sauceOptions);

        return capabilities;
    }

    public static MutableCapabilities launchInBrowser() {
        MutableCapabilities capabilities = new MutableCapabilities();
        capabilities.setCapability("platformName", "ios");
        capabilities.setCapability("browserName", "safari");
        capabilities.setCapability("appium:platformVersion", "18.7.2");
        capabilities.setCapability("appium:deviceName", "iPhone 15");
        capabilities.setCapability("appium:automationName", "XCUITest");

        capabilities.setCapability("appium:wdaLaunchTimeout", 60000);
        capabilities.setCapability("appium:wdaConnectionTimeout", 60000);
        capabilities.setCapability("appium:wdaStartupRetries", 3);
        capabilities.setCapability("appium:wdaStartupRetryInterval", 10000);

        // Sauce options
        HashMap<String, Object> sauceOptions = new HashMap<String, Object>();
        sauceOptions.put("username", "");
        sauceOptions.put("accessKey", "");
        sauceOptions.put("build", "Appium-Saucelabs Demo");
        sauceOptions.put("name", "for iphone browser");
        sauceOptions.put("appiumVersion", "latest");

        capabilities.setCapability("sauce:options", sauceOptions);

        return capabilities;
    }
}
