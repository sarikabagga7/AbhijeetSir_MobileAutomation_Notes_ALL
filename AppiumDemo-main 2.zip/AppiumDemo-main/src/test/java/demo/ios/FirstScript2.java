package demo.ios;

import java.io.File;
import java.net.URL;
import java.util.HashMap;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class FirstScript2 {
	
	public static String bundleid = "com.example.apple-samplecode.UICatalog";

	public static void main(String[] args) {
		AppiumDriverLocalService service = new AppiumServiceBuilder()
				.withAppiumJS(new File("/opt/homebrew/lib/node_modules/appium/build/lib/main.js"))
				.usingDriverExecutable(new File("/opt/homebrew/bin/node"))
				.withIPAddress("127.0.0.1")
				.usingPort(4723)
				.build();
		try {
			service.start();
			
			XCUITestOptions options = new XCUITestOptions();
			options.setDeviceName("iPhone 15");
			options.setPlatformVersion("17.0");
			options.setApp(System.getProperty("user.dir") + "/src/test/resources/apps/UIKitCatalog.app");
			options.setBundleId(bundleid);
			
			AppiumDriver driver = new IOSDriver(new URL("http://127.0.0.1:4723"), options);
			
			
			
			driver.findElement(AppiumBy.accessibilityId("Alert Views")).click();
			driver.findElement(AppiumBy.xpath("//XCUIElementTypeStaticText[@value='Simple']")).click();
			
			System.out.println(driver.findElement(AppiumBy.accessibilityId("A Short Title Is Best")).getAttribute("value"));
			
			driver.findElement(AppiumBy.accessibilityId("OK")).click();
			
			Thread.sleep(5000);
			
			((IOSDriver) driver).terminateApp(bundleid);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			service.stop();
		}

	}

}
