package demo.ios;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.openqa.selenium.By;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class PredicateStringDemo {
	
	public static String bundleid = "com.example.apple-samplecode.UICatalog";

	public static void main(String[] args) {
		AppiumDriverLocalService service = new AppiumServiceBuilder()
				.withAppiumJS(new File("/opt/homebrew/lib/node_modules/appium/build/lib/main.js"))
				.usingDriverExecutable(new File("/opt/homebrew/bin/node"))
				.withIPAddress("127.0.0.1")
				.usingPort(4723)
				.build();
		try {
			service.start();
			
			AppiumDriver driver = getDriver();
			
			launchApp(driver);
			
		    click(driver, AppiumBy.iOSNsPredicateString("name == 'Picker View'"));
		    
		    enterText(driver, 
		    		AppiumBy.iOSNsPredicateString("name == 'Red color component value' AND type == 'XCUIElementTypePickerWheel'"), "20");
		    enterText(driver, 
		    		AppiumBy.iOSNsPredicateString("name CONTAINS 'Green' AND type == 'XCUIElementTypePickerWheel'"), "20");
		    enterText(driver, 
		    		AppiumBy.iOSNsPredicateString("name BEGINSWITH 'Blue color' AND type == 'XCUIElementTypePickerWheel'"), "20");

		    Thread.sleep(2000);
		    
		    click(driver, 
		    		AppiumBy.xpath("//XCUIElementTypeNavigationBar/XCUIElementTypeButton[@name='UIKitCatalog']"));
		    
		    Thread.sleep(5000);
			
		    terminateApp(driver);
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			service.stop();
		}
	}
	
	public static AppiumDriver getDriver() throws MalformedURLException {
		XCUITestOptions options = new XCUITestOptions();
		options.setDeviceName("iPhone 15");
		options.setPlatformVersion("17.0");
		
		AppiumDriver driver = new IOSDriver(new URL("http://127.0.0.1:4723"), options);
		return driver;
	}
	
	public static void launchApp(AppiumDriver driver) {
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("bundleId", bundleid);
	    driver.executeScript("mobile: launchApp", params);
	}
	
	public static void terminateApp(AppiumDriver driver) {
		((IOSDriver) driver).terminateApp(bundleid);
	}
	
	public static void click(AppiumDriver driver, By locator) {
		driver.findElement(locator).click();
	}
	
	public static void enterText(AppiumDriver driver, By locator, String text) {
		driver.findElement(locator).sendKeys(text);
	}
	
	public static String getAttribute(AppiumDriver driver, By locator, String attributeName) {
		return driver.findElement(locator).getAttribute(attributeName);
	}

}
