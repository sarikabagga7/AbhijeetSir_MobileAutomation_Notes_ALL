package demo.ios;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.openqa.selenium.By;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class IOSClassChainDemo {
	
	public static String bundleid = "com.example.apple-samplecode.UICatalog";

	public static void main(String[] args) {
		AppiumDriverLocalService service = new AppiumServiceBuilder()
				.withAppiumJS(new File("/opt/homebrew/lib/node_modules/appium/build/lib/main.js"))
				.usingDriverExecutable(new File("/opt/homebrew/bin/node"))
				.withIPAddress("127.0.0.1")
				.usingPort(4723)
				.build();
		try {
			service.start();
			
			AppiumDriver driver = getDriver();
			
			launchApp(driver);
		    
		    click(driver, 
		    		AppiumBy.iOSClassChain("**/XCUIElementTypeStaticText[`name == 'Date Picker'`]"));		    
		    click(driver, 
		    		AppiumBy.iOSClassChain("**/XCUIElementTypeButton[`name == 'Date and Time Picker'`]/**/XCUIElementTypeButton[1]"));
		    click(driver, 
		    		AppiumBy.iOSClassChain("**/XCUIElementTypeButton[`label == 'Thursday, 4 December'`]"));		    
		    click(driver, 
		    		AppiumBy.accessibilityId("PopoverDismissRegion"));
		    		    
		    
		    click(driver, 
		    		AppiumBy.iOSClassChain("**/XCUIElementTypeButton[`name == 'Date and Time Picker'`]/**/XCUIElementTypeButton[2]"));
		    enterText(driver, 
		    		AppiumBy.iOSClassChain("**/XCUIElementTypeDatePicker/XCUIElementTypePicker/**/XCUIElementTypePickerWheel[1]"), "11");
		    enterText(driver, 
		    		AppiumBy.iOSClassChain("**/XCUIElementTypeDatePicker/XCUIElementTypePicker/**/XCUIElementTypePickerWheel[2]"), "54");
		    enterText(driver, 
		    		AppiumBy.iOSClassChain("**/XCUIElementTypeDatePicker/XCUIElementTypePicker/**/XCUIElementTypePickerWheel[3]"), "AM");
		    
		    Thread.sleep(1000);
		    
		    System.out.println("Selected date and time: " + 
		    		getAttribute(driver, 
		    				AppiumBy.iOSClassChain("**/XCUIElementTypeStaticText[`name CONTAINS 'at' AND  traits == 'StaticText'`]"), "value"));
				    
		    click(driver, 
		    		AppiumBy.accessibilityId("PopoverDismissRegion"));
		    
		    click(driver, 
		    		AppiumBy.xpath("//XCUIElementTypeNavigationBar/XCUIElementTypeButton[@name='UIKitCatalog']"));
		    
		    Thread.sleep(5000);
			
		    terminateApp(driver);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			service.stop();
		}

	}
	
	public static AppiumDriver getDriver() throws MalformedURLException {
		XCUITestOptions options = new XCUITestOptions();
		options.setDeviceName("iPhone 15");
		options.setPlatformVersion("17.0");
		
		AppiumDriver driver = new IOSDriver(new URL("http://127.0.0.1:4723"), options);
		return driver;
	}
	
	public static void launchApp(AppiumDriver driver) {
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("bundleId", bundleid);
	    driver.executeScript("mobile: launchApp", params);
	}
	
	public static void terminateApp(AppiumDriver driver) {
		((IOSDriver) driver).terminateApp(bundleid);
	}
	
	public static void click(AppiumDriver driver, By locator) {
		driver.findElement(locator).click();
	}
	
	public static void enterText(AppiumDriver driver, By locator, String text) {
		driver.findElement(locator).sendKeys(text);
	}
	
	public static String getAttribute(AppiumDriver driver, By locator, String attributeName) {
		return driver.findElement(locator).getAttribute(attributeName);
	}

}
