package demo.ios;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class ScrollGestureDemo {
	
	public static String bundleid = "com.nsoojin.BookStore";

	public static void main(String[] args) {
		AppiumDriverLocalService service = new AppiumServiceBuilder()
				.withAppiumJS(new File("/opt/homebrew/lib/node_modules/appium/build/lib/main.js"))
				.usingDriverExecutable(new File("/opt/homebrew/bin/node"))
				.withIPAddress("127.0.0.1")
				.usingPort(4723)
				.build();
		try {
			service.start();
			
			AppiumDriver driver = getDriver();
			
			launchApp(driver);
			
			//
			//
			scrollUsingPredicateString(driver, 
					AppiumBy.accessibilityId("NewBooksTableView"), "value == 'Azure Maps Using Blazor Succinctly'");
			
			scrollUsingName(driver, 
					AppiumBy.accessibilityId("NewBooksTableView"), "Reliable Machine Learning");
		   
		    Thread.sleep(5000);
			
		    terminateApp(driver);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			service.stop();
		}

	}
	
	public static AppiumDriver getDriver() throws MalformedURLException {
		XCUITestOptions options = new XCUITestOptions();
		options.setDeviceName("iPhone 15");
		options.setPlatformVersion("17.0");
		
		AppiumDriver driver = new IOSDriver(new URL("http://127.0.0.1:4723"), options);
		return driver;
	}
	
	public static void launchApp(AppiumDriver driver) {
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("bundleId", bundleid);
	    driver.executeScript("mobile: launchApp", params);
	}
	
	public static void terminateApp(AppiumDriver driver) {
		((IOSDriver) driver).terminateApp(bundleid);
	}
	
	public static void click(AppiumDriver driver, By locator) {
		driver.findElement(locator).click();
	}
	
	public static void tapGesture(AppiumDriver driver, By locator) {
		WebElement element = driver.findElement(locator);
		int startX = element.getLocation().getX();
		int startY = element.getLocation().getY();
		int width = element.getSize().width;
		int height = element.getSize().height;
		int centerX = startX + width/2;
		int centerY = startY + height/2;
		
		HashMap<String, Object> params = new HashMap<>();
		params.put("x", centerX);
		params.put("y", centerY);
		driver.executeScript("mobile: tap", params);
	}
	
	public static void tapGestureByRelativeCoords(AppiumDriver driver, By locator, int relativeX, int relativeY) {
		WebElement element = driver.findElement(locator);
		
		HashMap<String, Object> params = new HashMap<>();
		params.put("elementId", ((RemoteWebElement) element).getId());//20, 718  -> 59, 728
		params.put("x", relativeX);//39
		params.put("y", relativeY);//10
		driver.executeScript("mobile: tap", params);
	}
	
	public static void scrollUsingPredicateString(AppiumDriver driver, By scrollableLocator, String predicateString) {
		HashMap<String, Object> params = new HashMap<>();
		//params.put("elementId", driver.findElement(scrollableLocator));
		params.put("elementId", ((RemoteWebElement) driver.findElement(scrollableLocator)).getId());
		params.put("predicateString", predicateString);
		driver.executeScript("mobile: scroll", params);
	}
	
	public static void scrollUsingName(AppiumDriver driver, By scrollableLocator, String name) {
		HashMap<String, Object> params = new HashMap<>();
		//params.put("elementId", driver.findElement(scrollableLocator));
		params.put("elementId", ((RemoteWebElement) driver.findElement(scrollableLocator)).getId());
		params.put("name", name);
		driver.executeScript("mobile: scroll", params);
	}
	
	public static void enterText(AppiumDriver driver, By locator, String text) {
		driver.findElement(locator).sendKeys(text);
	}
	
	public static String getAttribute(AppiumDriver driver, By locator, String attributeName) {
		return driver.findElement(locator).getAttribute(attributeName);
	}

}
