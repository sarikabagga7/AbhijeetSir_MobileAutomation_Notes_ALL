package demo.queries;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
import org.openqa.selenium.WebElement;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;

public class ToggleAirplaneModeAndroidDemo {
    static String pkgName = "io.appium.android.apis";
    static String activity = "io.appium.android.apis.ApiDemos";

    static String settingsPkgName = "com.android.settings";
    static String settingsActivity = "com.android.settings.Settings";

    public static void main(String[] args) {
        AppiumDriverLocalService service = new AppiumServiceBuilder()
                .withAppiumJS(new File("/opt/homebrew/lib/node_modules/appium/build/lib/main.js"))
                .usingDriverExecutable(new File("/opt/homebrew/bin/node"))
                .withIPAddress("127.0.0.1")
                .usingPort(4723)
                .build();
        try {
            service.start();

            AppiumDriver driver = getDriver();
            //launch settings app
            launchSettingsApp(driver);
            //click on Network and Internet menu option
            driver.findElement(AppiumBy.xpath("//android.widget.TextView[@text='Network & internet']//ancestor::android.widget.LinearLayout[1]")).click();
            //toggle airplane mode switch to ON mode if not already ON
            WebElement toggleSwitch = driver.findElement(AppiumBy.id("com.android.settings:id/switchWidget"));
            if (!Boolean.parseBoolean(toggleSwitch.getAttribute("checked")))
                toggleSwitch.click();
            Thread.sleep(2000);
            //terminate settings app
            terminateApp(driver, settingsPkgName);
            //((AndroidDriver) driver).activateApp(settingsPkgName);

            launchUiCatalogsApp(driver);
            driver.findElement(AppiumBy.androidUIAutomator("new UiSelector().description(\"Views\")")).click();
            Thread.sleep(2000);
            terminateApp(driver, pkgName);

            //launch settings app
            launchSettingsApp(driver);
            //click on Network and Internet menu option
            driver.findElement(AppiumBy.xpath("//android.widget.TextView[@text='Network & internet']//ancestor::android.widget.LinearLayout[1]")).click();
            //toggle airplane mode switch to OFF mode if not already OFF
            WebElement toggleSwitch1 = driver.findElement(AppiumBy.id("com.android.settings:id/switchWidget"));
            if (Boolean.parseBoolean(toggleSwitch1.getAttribute("checked")))
                toggleSwitch1.click();
            Thread.sleep(2000);
            //terminate settings app
            terminateApp(driver, settingsPkgName);
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            service.stop();
        }
    }

    public static AppiumDriver getDriver() throws MalformedURLException {
        //Step 1 : Specify device details
        //Capabilities for the script
        UiAutomator2Options options = new UiAutomator2Options();
        //specify avd name
        options.setAvd("Pixel_7");

        //Step 2 : Connect to Appium Server
        AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
        //poll for 500ms for a max of 5secs and then throw NoSuchElementException
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        return driver;
    }

    public static void launchSettingsApp(AppiumDriver driver) {
        //Step 3: Specify App details
        String launchableActivity = settingsPkgName + "/" + settingsActivity;

        //Step 4: Launch the app
        HashMap<String, Object> params = new HashMap<String, Object>();
        params.put("intent", launchableActivity);
        driver.executeScript("mobile: startActivity", params);
    }

    public static void launchUiCatalogsApp(AppiumDriver driver) {
        //Step 3: Specify App details
        String launchableActivity = pkgName + "/" + activity;

        //Step 4: Launch the app
        HashMap<String, Object> params = new HashMap<String, Object>();
        params.put("intent", launchableActivity);
        driver.executeScript("mobile: startActivity", params);
    }

    public static void terminateApp(AppiumDriver driver, String pkgName) {
        ((AndroidDriver) driver).terminateApp(pkgName);
    }
}
