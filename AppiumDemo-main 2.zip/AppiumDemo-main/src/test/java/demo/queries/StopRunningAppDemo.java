package demo.queries;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

public class StopRunningAppDemo {
	static String pkgName = "io.appium.android.apis";
	static String activity = "io.appium.android.apis.ApiDemos";

	public static void main(String[] args) {
		AppiumDriverLocalService service = new AppiumServiceBuilder()
				.withAppiumJS(new File("/opt/homebrew/lib/node_modules/appium/build/lib/main.js"))
				.usingDriverExecutable(new File("/opt/homebrew/bin/node"))
				.withIPAddress("127.0.0.1")
				.usingPort(4723)
				.build();
		try {
			service.start();
			
			AppiumDriver driver = getDriver();
			
			//terminate any running instance of app.
			//Also use ((AndroidDriver) driver).removeApp(pkgName) to delete app if installed via code.
			terminateApp(driver);
			
			launchApp(driver);
			
			clickGestureById(driver, AppiumBy.xpath("//android.widget.TextView[@text='Views']"));
				
			Thread.sleep(5000);	
				
			terminateApp(driver);
			
		} catch (MalformedURLException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			service.stop();
		}

	}
	
	public static AppiumDriver getDriver() throws MalformedURLException {
		//Step 1 : Specify device details
		//Capabilities for the script
		UiAutomator2Options options = new UiAutomator2Options();
		//specify avd name
		options.setAvd("Pixel_7");
		//specify udid
		//options.setUdid("");
		
		//Step 2 : Connect to Appium Server
		AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
		//poll for 500ms for a max of 5secs and then throw NoSuchElementException
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		return driver;
	}
	
	public static void launchApp(AppiumDriver driver) {
		//Step 3: Specify App details
		String launchableActivity = pkgName + "/" + activity;
		
		//Step 4: Launch the app
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("intent", launchableActivity);
		driver.executeScript("mobile: startActivity", params);
	}
	
	public static void terminateApp(AppiumDriver driver) {
		((AndroidDriver) driver).terminateApp(pkgName);
	}
	
	public static void clickGestureById(AppiumDriver driver, By locator) {
		WebElement element = driver.findElement(locator);
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("elementId", ((RemoteWebElement)element).getId());
		driver.executeScript("mobile: clickGesture", params);
	}

}
