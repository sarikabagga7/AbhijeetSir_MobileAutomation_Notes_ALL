package demo.queries;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.options.XCUITestOptions;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class CrossBrowserTestingDemo {
    enum PlatformType {
        WEB,
        ANDROID,
        IOS
    }

    AppiumDriverLocalService service = new AppiumServiceBuilder()
            .withAppiumJS(new File("/opt/homebrew/lib/node_modules/appium/build/lib/main.js"))
            .usingDriverExecutable(new File("/opt/homebrew/bin/node"))
            .withIPAddress("127.0.0.1")
            .usingPort(4723)
            .build();

    public static void main(String[] args) throws InterruptedException, MalformedURLException {
        CrossBrowserTestingDemo object = new CrossBrowserTestingDemo();
        object.run(PlatformType.WEB, "https://www.saucedemo.com/");
    }

    public void run(PlatformType platformType, String url) throws MalformedURLException, InterruptedException {
        try {
            WebDriver driver = getDriver(platformType);
            driver.get(url);
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

            driver.findElement(By.id("user-name")).sendKeys("standard_user");
            driver.findElement(By.id("password")).sendKeys("secret_sauce");
            driver.findElement(By.id("login-button")).click();
            
            Thread.sleep(5000);

            driver.quit();
        } catch (RuntimeException e) {
            throw new RuntimeException(e);
        } finally {
            if (service.isRunning()) {
                service.stop();
            }
        }
    }

    public WebDriver getDriver(PlatformType platformType) throws MalformedURLException {
        if (platformType == PlatformType.WEB) {
            return launchInBrowser();
        } else if (platformType == PlatformType.ANDROID) {
            service.start();
            return launchInEmulator();
        } else if (platformType == PlatformType.IOS) {
            service.start();
            return launchInSimulator();
        } else {
            throw new RuntimeException("Unsupported Platform Type");
        }
    }

    public WebDriver launchInEmulator() throws MalformedURLException {
        UiAutomator2Options options = new UiAutomator2Options();
        options.setAvd("Pixel_7");
        options.setChromedriverExecutable(System.getProperty("user.dir") + "/drivers/chromedriver-mac-arm64/chromedriver");
        options.setCapability("browserName", "Chrome");

        return new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
    }

    public WebDriver launchInSimulator() throws MalformedURLException {
        XCUITestOptions options = new XCUITestOptions();
        options.setDeviceName("iPhone 15");
        options.setPlatformVersion("17.0");
        options.setCapability("browserName", "Safari");

        return new IOSDriver(new URL("http://127.0.0.1:4723"), options);
    }

    public WebDriver launchInBrowser() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--incognito");

        return new ChromeDriver(options);
    }
}
