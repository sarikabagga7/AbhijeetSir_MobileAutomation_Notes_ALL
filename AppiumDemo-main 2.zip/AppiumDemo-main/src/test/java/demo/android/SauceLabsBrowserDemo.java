package demo.android;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.MutableCapabilities;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;

public class SauceLabsBrowserDemo {
    public static void main(String[] args) throws MalformedURLException {
        AppiumDriver driver = null;
        try {
            MutableCapabilities capabilities = launchInBrowser();

            driver = new AndroidDriver(new URL("https://ondemand.eu-central-1.saucelabs.com:443/wd/hub"), capabilities);
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

            driver.get("https://www.saucedemo.com/");

            Thread.sleep(5000);

            driver.executeScript("sauce:job-result=passed");
        } catch (Exception e) {
            e.printStackTrace();
            driver.executeScript("sauce:job-result=failed");
        } finally {
            if (driver != null)
                driver.quit();
        }

    }

    public static MutableCapabilities launchInBrowser() {
        MutableCapabilities capabilities = new MutableCapabilities();
        capabilities.setCapability("platformName", "android");
        capabilities.setCapability("browserName", "chrome");
        capabilities.setCapability("appium:platformVersion", "16");
        capabilities.setCapability("appium:deviceName", "Samsung Galaxy S23 FE");
        capabilities.setCapability("appium:automationName", "UiAutomator2");

        // Sauce options
        HashMap<String, Object> sauceOptions = new HashMap<String, Object>();
        sauceOptions.put("username", "");
        sauceOptions.put("accessKey", "");
        sauceOptions.put("build", "Appium-Saucelabs Demo");
        sauceOptions.put("name", "for android browser");
        sauceOptions.put("appiumVersion", "latest");

        capabilities.setCapability("sauce:options", sauceOptions);
        return capabilities;
    }
}
