package demo.android;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
/*
 * Demo for different click gestures
 */
public class ClickGestureDemo {
	static String pkgName = "io.appium.android.apis";
	static String activity = "io.appium.android.apis.ApiDemos";

	public static void main(String[] args) {
		try {
			AppiumDriver driver = getDriver();
			launchApp(driver);
			
			//click(driver, AppiumBy.xpath("//android.widget.TextView[@text='Views']"));	
			clickGestureById(driver, AppiumBy.xpath("//android.widget.TextView[@text='Views']"));
			clickGestureByCoords(driver, AppiumBy.accessibilityId("Buttons"));
			
			Thread.sleep(5000);
			
			terminateApp(driver);
		} catch (MalformedURLException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public static AppiumDriver getDriver() throws MalformedURLException {
		//Step 1 : Specify device details
		//Capabilities for the script
		UiAutomator2Options options = new UiAutomator2Options();
		//specify avd name
		options.setAvd("Pixel_8");
		//specify udid
		//options.setUdid("");
		
		//Step 2 : Connect to Appium Server
		AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
		//poll for 500ms for a max of 5secs and then throw NoSuchElementException
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		return driver;
	}
	
	public static void launchApp(AppiumDriver driver) {
		//Step 3: Specify App details
		String launchableActivity = pkgName + "/" + activity;
		
		//Step 4: Launch the app
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("intent", launchableActivity);
		driver.executeScript("mobile: startActivity", params);
	}
	
	public static void terminateApp(AppiumDriver driver) {
		((AndroidDriver) driver).terminateApp(pkgName);
	}
	
	public static void click(AppiumDriver driver, By locator) {
		driver.findElement(locator).click();
	}
	
	public static void clickGestureById(AppiumDriver driver, By locator) {
		WebElement element = driver.findElement(locator);
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("elementId", ((RemoteWebElement)element).getId());
		driver.executeScript("mobile: clickGesture", params);
	}
	
	public static void enterText(AppiumDriver driver, By locator, String text) {
		driver.findElement(locator).sendKeys(text);
	}
	
	public static void clickGestureByCoords(AppiumDriver driver, By locator) {
		WebElement element = driver.findElement(locator);
		int x = element.getLocation().getX();
		int y = element.getLocation().getY();
		int width = element.getSize().getWidth();
		int height = element.getSize().getHeight();
		int centerX = x + width/2;
		int centerY = y + height/2;
		
		//int -> Integer
		//float -> Float
		
		HashMap<String, Object> params = new HashMap<>();
		params.put("x", centerX);
		params.put("y", centerY);
		driver.executeScript("mobile: clickGesture", params);
	}

}
