package demo.android;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
/*
 * Demo for different scroll gestures
 */
public class ScrollGestureDemo {
	static String pkgName = "io.appium.android.apis";
	static String activity = "io.appium.android.apis.ApiDemos";

	public static void main(String[] args) {
		try {
			AppiumDriver driver = getDriver();
			launchApp(driver);
			
			//click(driver, AppiumBy.xpath("//android.widget.TextView[@text='Views']"));	
			clickGestureById(driver, AppiumBy.xpath("//android.widget.TextView[@text='Views']"));

			//#1 Scroll
			By targetMenuOption = AppiumBy.androidUIAutomator(
					"new UiScrollable(new UiSelector().resourceId(\"android:id/list\")).scrollIntoView(new UiSelector().text(\"Rotating Button\"))");
			scrollGestureUsingUiAutomator(driver, targetMenuOption);
			
			//#2 Scroll
			//scrollGestureById(driver, AppiumBy.id("android:id/list"), AppiumBy.accessibilityId("Rotating Button"), "down");
			
			//#3 Scroll
			//scrollGestureByCoords(driver, AppiumBy.accessibilityId("Rotating Button"), "down");
	
			Thread.sleep(5000);
			
			terminateApp(driver);
		} catch (MalformedURLException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public static AppiumDriver getDriver() throws MalformedURLException {
		//Step 1 : Specify device details
		//Capabilities for the script
		UiAutomator2Options options = new UiAutomator2Options();
		//specify avd name
		options.setAvd("Pixel_8");
		//specify udid
		//options.setUdid("");
		
		//Step 2 : Connect to Appium Server
		AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
		//poll for 500ms for a max of 5secs and then throw NoSuchElementException
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		return driver;
	}
	
	public static void launchApp(AppiumDriver driver) {
		//Step 3: Specify App details
		String launchableActivity = pkgName + "/" + activity;
		
		//Step 4: Launch the app
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("intent", launchableActivity);
		driver.executeScript("mobile: startActivity", params);
	}
	
	public static void terminateApp(AppiumDriver driver) {
		((AndroidDriver) driver).terminateApp(pkgName);
	}
	
	public static void click(AppiumDriver driver, By locator) {
		driver.findElement(locator).click();
	}
	
	public static void clickGestureById(AppiumDriver driver, By locator) {
		WebElement element = driver.findElement(locator);
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("elementId", ((RemoteWebElement)element).getId());
		driver.executeScript("mobile: clickGesture", params);
	}
	
	public static void enterText(AppiumDriver driver, By locator, String text) {
		driver.findElement(locator).sendKeys(text);
	}
	
	public static void clickGestureByCoords(AppiumDriver driver, By locator) {
		WebElement element = driver.findElement(locator);
		int x = element.getLocation().getX();
		int y = element.getLocation().getY();
		int width = element.getSize().getWidth();
		int height = element.getSize().getHeight();
		int centerX = x + width/2;
		int centerY = y + height/2;
		
		HashMap<String, Object> params = new HashMap<>();
		params.put("x", centerX);
		params.put("y", centerY);
		driver.executeScript("mobile: clickGesture", params);
	}
	
	public static void scrollGestureById(AppiumDriver driver, By scrollCntrLocator, By targetLocator, String direction) {
		HashMap<String, Object> params = new HashMap<>();
		params.put("elementId", ((RemoteWebElement) driver.findElement(scrollCntrLocator)).getId());
		params.put("direction", direction);
		params.put("percent", 0.3);
		
		Boolean canScrollMore = true;
		while (!isElementDisplayed(driver, targetLocator) && (canScrollMore == true)) {
			canScrollMore = (Boolean) driver.executeScript("mobile: scrollGesture", params);
		}
	}
	
	public static void scrollGestureByCoords(AppiumDriver driver, By locator, String direction) {
		HashMap<String, Object> params = new HashMap<>();
		params.put("left", 700);
		params.put("top", 550);
		params.put("width", 300);
		params.put("height", 1400);
		params.put("direction", direction);
		params.put("percent", 0.3);
		
		Boolean canScrollMore = true;
		while (canScrollMore && !isElementDisplayed(driver, locator)) {
			canScrollMore = (Boolean) driver.executeScript("mobile: scrollGesture", params);
		}
	}
	
	public static WebElement scrollGestureUsingUiAutomator(AppiumDriver driver, By locator) {
		WebElement element = driver.findElement(locator);
		return element;
	}
	
	public static boolean isElementDisplayed(AppiumDriver driver, By locator) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2));
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			return true;
		} catch (TimeoutException e) {
			return false;
		}
	}
}
