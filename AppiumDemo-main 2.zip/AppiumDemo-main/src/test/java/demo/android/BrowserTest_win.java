package demo.android;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;

import java.io.File;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

public class BrowserTest_win {
    private static AppiumDriverLocalService service = null;

    public static void main(String[] args) {
    	BrowserTest_win object = new BrowserTest_win();
        try {
            object.startService();

            UiAutomator2Options options = new UiAutomator2Options();
            options.setAvd("Pixel_7");
            options.setChromedriverExecutable(System.getProperty("user.dir") + "\\drivers\\chromedriver-win64\\chromedriver.exe");
            options.setCapability("browserName", "Chrome");

            AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
            driver.get("http://google.co.in");
            
            driver.findElement(By.name("q")).sendKeys("Hello World", Keys.ENTER);

            Thread.sleep(10000);


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            object.stopSevice();
        }
    }

    public void startService() {
        service = new AppiumServiceBuilder()
                .withAppiumJS(new File("C:\\Users\\autom\\AppData\\Roaming\\npm\\node_modules\\appium\\build\\lib\\main.js"))
                //.usingDriverExecutable(new File("/usr/local/bin/node"))
                .usingDriverExecutable(new File("C:\\Program Files\\nodejs\\node.exe"))
                .withIPAddress("127.0.0.1").usingPort(4723).build();
        service.start();
    }

    public void stopSevice() {
        if (service != null) {
            service.stop();
        }
    }
}
