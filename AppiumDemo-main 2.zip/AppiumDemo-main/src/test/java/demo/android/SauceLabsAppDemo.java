package demo.android;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.MutableCapabilities;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;

public class SauceLabsAppDemo {
    public static void main(String[] args) throws MalformedURLException {
        AppiumDriver driver = null;
        try {
            MutableCapabilities capabilities = launchInEmulator();

            driver = new AndroidDriver(new URL("https://ondemand.eu-central-1.saucelabs.com:443/wd/hub"), capabilities);
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));

            driver.findElement(AppiumBy.accessibilityId("test-Username")).sendKeys("standard_user");
            driver.findElement(AppiumBy.accessibilityId("test-Password")).sendKeys("secret_sauce");
            driver.findElement(AppiumBy.accessibilityId("test-LOGIN")).click();

            Thread.sleep(5000);

            driver.executeScript("sauce:job-result=passed");
        } catch (Exception e) {
            e.printStackTrace();
            driver.executeScript("sauce:job-result=failed");
        } finally {
            if (driver != null)
                driver.quit();
        }

    }

    private static MutableCapabilities launchInEmulator() {
        MutableCapabilities capabilities = new MutableCapabilities();
        capabilities.setCapability("platformName", "android");
        capabilities.setCapability("appium:platformVersion", "16.0");
        capabilities.setCapability("appium:deviceName", "Google Pixel 9 Emulator");
        capabilities.setCapability("appium:automationName", "UiAutomator2");
        capabilities.setCapability("appium:app", "storage:filename=Android.SauceLabs.Mobile.Sample.app.2.7.1.apk");
        capabilities.setCapability("appium:noReset", false);
        capabilities.setCapability("appium:appWaitActivity", "com.swaglabsmobileapp.*");
        capabilities.setCapability("appium:appWaitDuration", 10000);
        // Sauce options
        HashMap<String, Object> sauceOptions = new HashMap<String, Object>();
        sauceOptions.put("username", "");
        sauceOptions.put("accessKey", "");
        sauceOptions.put("build", "Appium-Saucelabs Demo");
        sauceOptions.put("name", "for android emulator");

        capabilities.setCapability("sauce:options", sauceOptions);

        return capabilities;
    }

    private static MutableCapabilities launchInRealDevice() {
        MutableCapabilities capabilities = new MutableCapabilities();
        capabilities.setCapability("platformName", "android");
        capabilities.setCapability("appium:platformVersion", "16");
        capabilities.setCapability("appium:deviceName", "Samsung Galaxy S23 FE");
        capabilities.setCapability("appium:automationName", "UiAutomator2");
        capabilities.setCapability("appium:app", "storage:filename=Android.SauceLabs.Mobile.Sample.app.2.7.1.apk");
        capabilities.setCapability("appium:noReset", false);
        capabilities.setCapability("appium:appWaitActivity", "com.swaglabsmobileapp.*");
        capabilities.setCapability("appium:appWaitDuration", 10000);
        // Sauce options
        HashMap<String, Object> sauceOptions = new HashMap<String, Object>();
        sauceOptions.put("username", "");
        sauceOptions.put("accessKey", "");
        sauceOptions.put("build", "Appium-Saucelabs Demo");
        sauceOptions.put("name", "for android real device");
        sauceOptions.put("appiumVersion", "latest");

        capabilities.setCapability("sauce:options", sauceOptions);

        return capabilities;
    }
}
