package demo.android;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

public class MyFirstScriptPreinstalled {

	public static void main(String[] args) {
		try {
			//Step 1 : Specify device details
			//Capabilities for the script
			UiAutomator2Options options = new UiAutomator2Options();
			//specify avd name
			options.setAvd("Pixel_8");
			//specify udid
			//options.setUdid("");
			
			//Step 2 : Connect to Appium Server
			AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
			
			//Step 3: Specify App details
			String pkgName = "io.appium.android.apis";
			String activity = "io.appium.android.apis.ApiDemos";
			String launchableActivity = pkgName + "/" + activity;
			
			//Step 4: Launch the app
			HashMap<String, Object> params = new HashMap<String, Object>();
			params.put("intent", launchableActivity);
			driver.executeScript("mobile: startActivity", params);
			
			Thread.sleep(5000);
			
			((AndroidDriver) driver).terminateApp(pkgName);
			
		} catch (MalformedURLException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
