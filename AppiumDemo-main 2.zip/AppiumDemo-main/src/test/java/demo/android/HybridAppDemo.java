package demo.android;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import io.appium.java_client.service.local.AppiumServiceBuilder;
/*
 * Demo for handling Web View part of hybrid apps
 */
public class HybridAppDemo {
	static String pkgName = "com.swaglabsmobileapp";
	static String activity = "com.swaglabsmobileapp.MainActivity";

	public static void main(String[] args) {
		AppiumDriverLocalService service = new AppiumServiceBuilder()
				.withAppiumJS(new File("C:\\Users\\autom\\AppData\\Roaming\\npm\\node_modules\\appium\\build\\lib\\main.js"))
				.usingDriverExecutable(new File("C:\\Program Files\\nodejs\\node.exe"))
				.withIPAddress("127.0.0.1")
				.usingPort(4723)
				.build();
		try {
			service.start();
			
			AppiumDriver driver = getDriver();
			launchApp(driver);
			
			//Login
			enterText(driver, AppiumBy.accessibilityId("test-Username"), "standard_user");
			enterText(driver, AppiumBy.accessibilityId("test-Password"), "secret_sauce");
			clickGestureById(driver, AppiumBy.accessibilityId("test-LOGIN"));
			
			clickGestureById(driver, AppiumBy.accessibilityId("test-Menu"));
			clickGestureById(driver, AppiumBy.accessibilityId("test-WEBVIEW"));
			
			enterText(driver, AppiumBy.accessibilityId("test-enter a https url here..."), "https://www.google.co.in");
			clickGestureById(driver, AppiumBy.accessibilityId("test-GO TO SITE"));
			
			//2 types of contexts -> Native & Web View
			
			switchToWebView(driver);
			//Handle web page using selenium code
		    driver.findElement(By.name("q")).sendKeys("Hello World", Keys.ENTER);
			Thread.sleep(5000);
			
			switchToNativeView(driver);
			clickGestureById(driver, AppiumBy.accessibilityId("test-Menu"));
			Thread.sleep(5000);
			
			terminateApp(driver);
			
		} catch (MalformedURLException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			service.stop();
		}
	}
	
	public static AppiumDriver getDriver() throws MalformedURLException {
		//Step 1 : Specify device details
		//Capabilities for the script
		UiAutomator2Options options = new UiAutomator2Options();
		//specify avd name
		options.setAvd("Pixel_8");
		options.setChromedriverExecutable("C:\\Users\\autom\\workspace\\AppiumDemo\\drivers\\chromedriver-win64\\chromedriver.exe");
		//specify udid
		//options.setUdid("");
		
		//Step 2 : Connect to Appium Server
		AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
		//poll for 500ms for a max of 5secs and then throw NoSuchElementException
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		return driver;
	}
	
	public static void launchApp(AppiumDriver driver) {
		//Step 3: Specify App details
		String launchableActivity = pkgName + "/" + activity;
		
		//Step 4: Launch the app
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("intent", launchableActivity);
		driver.executeScript("mobile: startActivity", params);
	}
	
	public static void terminateApp(AppiumDriver driver) {
		((AndroidDriver) driver).terminateApp(pkgName);
	}
	
	public static void click(AppiumDriver driver, By locator) {
		driver.findElement(locator).click();
	}
	
	public static void clickGestureById(AppiumDriver driver, By locator) {
		WebElement element = driver.findElement(locator);
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("elementId", ((RemoteWebElement)element).getId());
		driver.executeScript("mobile: clickGesture", params);
	}
	
	public static void enterText(AppiumDriver driver, By locator, String text) {
		driver.findElement(locator).sendKeys(text);
	}
	
	public static void clickGestureByCoords(AppiumDriver driver, By locator) {
		WebElement element = driver.findElement(locator);
		int x = element.getLocation().getX();
		int y = element.getLocation().getY();
		int width = element.getSize().getWidth();
		int height = element.getSize().getHeight();
		int centerX = x + width/2;
		int centerY = y + height/2;
		
		HashMap<String, Object> params = new HashMap<>();
		params.put("x", centerX);
		params.put("y", centerY);
		driver.executeScript("mobile: clickGesture", params);
	}
	
	public static void scrollGestureById(AppiumDriver driver) {
		HashMap<String, Object> params = new HashMap<>();
		params.put("elementId", ((RemoteWebElement) driver.findElement(AppiumBy.id("android:id/list"))).getId());
		params.put("direction", "down");
		params.put("percent", 0.3);
		
		By targetLocator = AppiumBy.accessibilityId("Rotating Button 1");
		Boolean canScrollMore = true;
		while (!isElementDisplayed(driver, targetLocator) && (canScrollMore == true)) {
			canScrollMore = (Boolean) driver.executeScript("mobile: scrollGesture", params);
		}
	}
	
	public static void scrollGestureByCoords(AppiumDriver driver, By locator, String direction) {
		HashMap<String, Object> params = new HashMap<>();
		params.put("left", 700);
		params.put("top", 550);
		params.put("width", 300);
		params.put("height", 1400);
		params.put("direction", direction);
		params.put("percent", 0.3);
		
		Boolean canScrollMore = true;
		while (canScrollMore && !isElementDisplayed(driver, locator)) {
			canScrollMore = (Boolean) driver.executeScript("mobile: scrollGesture", params);
		}
	}
	
	public static void dragGestureByIdToCoords(AppiumDriver driver, By locator, int endX, int endY) {
		WebElement src = driver.findElement(AppiumBy.id("io.appium.android.apis:id/drag_dot_1"));
		HashMap<String, Object> params = new HashMap<>();
		params.put("elementId", ((RemoteWebElement) src).getId());
		params.put("endX", 600);
		params.put("endY", 700);
		
		driver.executeScript("mobile: dragGesture", params);
	}
	
	public static WebElement scrollGestureUsingUiAutomator(AppiumDriver driver, By locator) {
		WebElement element = driver.findElement(locator);
		return element;
	}
	
	public static void longClickGestureById(AppiumDriver driver, By locator, int timeInSecs) {
		WebElement element = driver.findElement(locator);
		HashMap<String, Object> params = new HashMap<>();
		params.put("elementId", ((RemoteWebElement)element).getId());
		params.put("duration", timeInSecs*1000);
		
		driver.executeScript("mobile: longClickGesture", params);
	}
	
	public static void longClickGestureByCoords(AppiumDriver driver, By locator, int timeInSecs) {
		WebElement element = driver.findElement(locator);
		
		int startX = element.getLocation().getX();
		int startY = element.getLocation().getY();
		int width = element.getSize().getWidth();
		int height = element.getSize().getHeight();
		
		HashMap<String, Object> params = new HashMap<>();
		params.put("x", startX + width/2);
		params.put("y", startY + height/2);
		params.put("duration", timeInSecs * 1000);
		
		driver.executeScript("mobile: longClickGesture", params);
	}
	
	public static boolean isElementDisplayed(AppiumDriver driver, By locator) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2));
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
			return true;
		} catch (TimeoutException e) {
			return false;
		}
	}
	
	public static void pressKey(AppiumDriver driver, AndroidKey key) {
		((AndroidDriver) driver).pressKey(new KeyEvent(key));
	}
	
	public static void switchToWebView(AppiumDriver driver) {
		System.out.println("Current context (before switch): " + ((AndroidDriver) driver).getContext());
		Set<String> contexts = ((AndroidDriver) driver).getContextHandles();
		for (String context : contexts) {
			if (context.contains("WEBVIEW")) {
				((AndroidDriver) driver).context(context);
				break;
			}
		}
		System.out.println("Current context (after switch): " + ((AndroidDriver) driver).getContext());
	}
	
	public static void switchToNativeView(AppiumDriver driver) {
		System.out.println("Current context (before switch): " + ((AndroidDriver) driver).getContext());
		((AndroidDriver) driver).context("NATIVE_APP");
		System.out.println("Current context (after switch): " + ((AndroidDriver) driver).getContext());
	}
}
