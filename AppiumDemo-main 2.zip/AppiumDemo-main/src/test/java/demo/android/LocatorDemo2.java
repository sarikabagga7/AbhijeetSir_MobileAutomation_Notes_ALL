package demo.android;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
/*
 * Demo for android ui automator
 */
public class LocatorDemo2 {
	static String pkgName = "io.appium.android.apis";
	static String activity = "io.appium.android.apis.ApiDemos";

	public static void main(String[] args) {
		try {
			AppiumDriver driver = getDriver();
			launchApp(driver);
			//poll for 500ms for a max of 5secs and then throw NoSuchElementException
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			
			click(driver, AppiumBy.androidUIAutomator("new UiSelector().description(\"Views\")"));
			click(driver, AppiumBy.androidUIAutomator("new UiSelector().description(\"Date Widgets\")"));
			click(driver, AppiumBy.androidUIAutomator("new UiSelector().textContains(\"Dialog\")"));
			click(driver, AppiumBy.androidUIAutomator("new UiSelector().resourceId(\"io.appium.android.apis:id/pickDate\").description(\"change the date\")"));
			
			//if element not found within max time period, it will TimeoutException
			//WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
			FluentWait<AppiumDriver> wait = new FluentWait<>(driver)
					.pollingEvery(Duration.ofSeconds(1))
					.withTimeout(Duration.ofSeconds(3))
					.ignoring(NoSuchElementException.class)
					.withMessage("Element not found");
			wait.until(ExpectedConditions.visibilityOfElementLocated(
					AppiumBy.androidUIAutomator("new UiSelector().resourceId(\"android:id/month_view\").childSelector(new UiSelector().description(\"10 November 2025\"))")));
			
			click(driver, AppiumBy.androidUIAutomator("new UiSelector().resourceId(\"android:id/month_view\").childSelector(new UiSelector().description(\"10 November 2025\"))"));
			click(driver, AppiumBy.androidUIAutomator("new UiSelector().resourceId(\"android:id/month_view\").childSelector(new UiSelector().className(\"android.view.View\").instance(11))"));
			Thread.sleep(5000);
			
			terminateApp(driver);
		} catch (MalformedURLException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public static AppiumDriver getDriver() throws MalformedURLException {
		//Step 1 : Specify device details
		//Capabilities for the script
		UiAutomator2Options options = new UiAutomator2Options();
		//specify avd name
		options.setAvd("Pixel_8");
		//specify udid
		//options.setUdid("");
		
		//Step 2 : Connect to Appium Server
		AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
		return driver;
	}
	
	public static void launchApp(AppiumDriver driver) {
		//Step 3: Specify App details
		String launchableActivity = pkgName + "/" + activity;
		
		//Step 4: Launch the app
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("intent", launchableActivity);
		driver.executeScript("mobile: startActivity", params);
	}
	
	public static void terminateApp(AppiumDriver driver) {
		((AndroidDriver) driver).terminateApp(pkgName);
	}
	
	public static void click(AppiumDriver driver, By locator) {
		driver.findElement(locator).click();
	}

}
