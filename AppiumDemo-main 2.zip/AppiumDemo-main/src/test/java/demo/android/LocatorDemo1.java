package demo.android;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.WebElement;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
/*
 * Demo for resource id and accessbility id
 */
public class LocatorDemo1 {
	static String pkgName = "io.appium.android.apis";
	static String activity = "io.appium.android.apis.ApiDemos";

	public static void main(String[] args) {
		try {
			AppiumDriver driver = getDriver();
			launchApp(driver);
			
			Thread.sleep(5000);
			
			click(driver, AppiumBy.accessibilityId("Views"));
			click(driver, AppiumBy.accessibilityId("Buttons"));
			click(driver, AppiumBy.id("io.appium.android.apis:id/button_toggle"));
			
			Thread.sleep(5000);
			
			terminateApp(driver);
		} catch (MalformedURLException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public static AppiumDriver getDriver() throws MalformedURLException {
		//Step 1 : Specify device details
		//Capabilities for the script
		UiAutomator2Options options = new UiAutomator2Options();
		//specify avd name
		options.setAvd("Pixel_8");
		//specify udid
		//options.setUdid("");
		
		//Step 2 : Connect to Appium Server
		AppiumDriver driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), options);
		return driver;
	}
	
	public static void launchApp(AppiumDriver driver) {
		//Step 3: Specify App details
		String launchableActivity = pkgName + "/" + activity;
		
		//Step 4: Launch the app
		HashMap<String, Object> params = new HashMap<String, Object>();
		params.put("intent", launchableActivity);
		driver.executeScript("mobile: startActivity", params);
	}
	
	public static void terminateApp(AppiumDriver driver) {
		((AndroidDriver) driver).terminateApp(pkgName);
	}
	
	public static void click(AppiumDriver driver, By locator) {
		driver.findElement(locator).click();
	}

}
