package com.saucedemo.apps.test;

import com.saucedemo.apps.controller.AppiumDriverManager;
import com.saucedemo.apps.pages.LoginPage;
import com.saucedemo.apps.pages.ProductsPage;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTests {
    @Test(description = "Verify user is able to login using valid credentials.",
            groups = {"sanity", "regression"})
    public void loginUsingValidCredentials() {
        try {
            AppiumDriver driver = AppiumDriverManager.getDriver();
            //Login
            LoginPage loginPage = new LoginPage(driver);
            loginPage.login("standard_user", "secret_sauce");
            loginPage.validateNoErrorMessageDisplayed();
            //Validate login
            ProductsPage productPage = new ProductsPage(driver);
            productPage.validateNavigationToProductsPage();
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Error: " + e.getMessage());
        }
    }

    @Test(description = "Verify user is not able to login using locked out credentials.",
            groups = {"regression"})
    public void loginUsingLockedoutCredentials() {
        try {
            AppiumDriver driver = AppiumDriverManager.getDriver();
            //Login
            LoginPage loginPage = new LoginPage(driver);
            loginPage.login("locked_out_user", "secret_sauce");
            //Validate login
            loginPage.validateErrorMessage("Sorry, this user has been locked out.");
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Error: " + e.getMessage());
        }
    }
}
