package com.saucedemo.apps.pages.interfaces;

import com.saucedemo.apps.object.User;

public interface ICheckoutInformationPage {
	public void validateNavigationToCheckoutInfoPage();
	public void setCheckoutInfo(User user);
}
