package com.saucedemo.apps.test;

import com.saucedemo.apps.base.BaseTest;
import com.saucedemo.apps.controller.AppiumDriverManager;
import com.saucedemo.apps.object.User;
import com.saucedemo.apps.pages.CartPage;
import com.saucedemo.apps.pages.CheckoutInformationPage;
import com.saucedemo.apps.pages.LoginPage;
import com.saucedemo.apps.pages.ProductsPage;
import com.saucedemo.apps.utils.TestDataUtils;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Map;

public class CheckoutTests extends BaseTest {
    @Test(description = "[Checkout-001] Verify user is able to checkout using single product.",
            groups = {"sanity", "regression"})
    public void checkoutUsingSingleProduct() {
        try {
            AppiumDriver driver = AppiumDriverManager.getDriver();
            //Read Data
            Map<String, String> dataMap = TestDataUtils.getData(
                    "Regression_TestData.xlsx", "CheckoutTests", "Checkout-001");
            //Login
            LoginPage loginPage = new LoginPage(driver);
            loginPage.login(dataMap.get("UserName"), dataMap.get("Password"));
            loginPage.validateNoErrorMessageDisplayed();
            //Add Product to Cart
            ProductsPage productPage = new ProductsPage(driver);
            productPage.addproductToCart(dataMap.get("ProductName"));
            productPage.clickCartButton();
            //Validate Cart Page
            CartPage cartPage = new CartPage(driver);
            cartPage.validateNavigationToCartPage();
            cartPage.validateProductDisplayed(dataMap.get("ProductName"));
            cartPage.clickCheckoutButton();
            //Enter Checkout Information
            User userObject = new User(
                    dataMap.get("FirstName"), dataMap.get("LastName"), dataMap.get("ZipCode"));
            CheckoutInformationPage checkoutInfo = new CheckoutInformationPage(driver);
            checkoutInfo.validateNavigationToCheckoutInfoPage();
            checkoutInfo.setCheckoutInfo(userObject);
        } catch (Exception e) {
            Assert.fail("Exception occurred: " + e.getMessage());
        }
    }

    @Test(description = "[Checkout-002] Verify user is able to checkout using multiple products.",
            groups = {"regression", "develop"})
    public void checkoutUsingMultipleProducts() {
        try {
            AppiumDriver driver = AppiumDriverManager.getDriver();
            //Read Data
            Map<String, String> dataMap = TestDataUtils.getData(
                    "Regression_TestData.xlsx", "CheckoutTests", "Checkout-002");
            //Login
            LoginPage loginPage = new LoginPage(driver);
            loginPage.login(dataMap.get("UserName"), dataMap.get("Password"));
            loginPage.validateNoErrorMessageDisplayed();
            //Add Products to Cart
            ProductsPage productPage = new ProductsPage(driver);
            String[] productsArray = dataMap.get("ProductName").split("\\|");
            for (String product : productsArray) {
                productPage.addproductToCart(product);
            }
            productPage.clickCartButton();
            //Validate Cart Page
            CartPage cartPage = new CartPage(driver);
            cartPage.validateNavigationToCartPage();
            for (String product : productsArray) {
                cartPage.validateProductDisplayed(product);
            }
            cartPage.clickCheckoutButton();
            //Enter Checkout Information
            User userObject = new User(
                    dataMap.get("FirstName"), dataMap.get("LastName"), dataMap.get("ZipCode"));
            CheckoutInformationPage checkoutInfo = new CheckoutInformationPage(driver);
            checkoutInfo.validateNavigationToCheckoutInfoPage();
            checkoutInfo.setCheckoutInfo(userObject);
        } catch (Exception e) {
            Assert.fail("Exception occurred: " + e.getMessage());
        }
    }
}
