package com.saucedemo.apps.test;

import com.saucedemo.apps.base.BaseTest;
import com.saucedemo.apps.controller.AppiumDriverManager;
import com.saucedemo.apps.object.User;
import com.saucedemo.apps.pages.CartPage;
import com.saucedemo.apps.pages.CheckoutInformationPage;
import com.saucedemo.apps.pages.LoginPage;
import com.saucedemo.apps.pages.ProductsPage;
import io.appium.java_client.AppiumDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CheckoutTests extends BaseTest {
    @Test
    public void checkoutUsingSingleProduct() {
        try {
            AppiumDriver driver = AppiumDriverManager.getDriver();
            //Login
            LoginPage loginPage = new LoginPage(driver);
            loginPage.login("standard_user", "secret_sauce");
            loginPage.validateNoErrorMessageDisplayed();
            //Add Product to Cart
            ProductsPage productPage = new ProductsPage(driver);
            productPage.addproductToCart("Sauce Labs Fleece Jacket");
            productPage.clickCartButton();
            //Validate Cart Page
            CartPage cartPage = new CartPage(driver);
            cartPage.validateNavigationToCartPage();
            cartPage.validateProductDisplayed("Sauce Labs Fleece Jacket");
            cartPage.clickCheckoutButton();
            //Enter Checkout Information
            User userObject = new User(
                    "Abhijeet", "Podder", "100345");
            CheckoutInformationPage checkoutInfo = new CheckoutInformationPage(driver);
            checkoutInfo.validateNavigationToCheckoutInfoPage();
            checkoutInfo.setCheckoutInfo(userObject);
        } catch (Exception e) {
            Assert.fail("Exception occurred: " + e.getMessage());
        }
    }

    @Test
    public void checkoutUsingMultipleProducts() {
        try {
            AppiumDriver driver = AppiumDriverManager.getDriver();
            //Login
            LoginPage loginPage = new LoginPage(driver);
            loginPage.login("standard_user", "secret_sauce");
            loginPage.validateNoErrorMessageDisplayed();
            //Add Products to Cart
            ProductsPage productPage = new ProductsPage(driver);
            productPage.addproductToCart("Sauce Labs Fleece Jacket");
            productPage.addproductToCart("Sauce Labs Backpack");
            productPage.clickCartButton();
            //Validate Cart Page
            CartPage cartPage = new CartPage(driver);
            cartPage.validateNavigationToCartPage();
            cartPage.validateProductDisplayed("Sauce Labs Fleece Jacket");
            cartPage.validateProductDisplayed("Sauce Labs Backpack");
            cartPage.clickCheckoutButton();
            //Enter Checkout Information
            User userObject = new User(
                    "Abhijeet", "Podder", "100345");
            CheckoutInformationPage checkoutInfo = new CheckoutInformationPage(driver);
            checkoutInfo.validateNavigationToCheckoutInfoPage();
            checkoutInfo.setCheckoutInfo(userObject);
        } catch (Exception e) {
            Assert.fail("Exception occurred: " + e.getMessage());
        }
    }
}
