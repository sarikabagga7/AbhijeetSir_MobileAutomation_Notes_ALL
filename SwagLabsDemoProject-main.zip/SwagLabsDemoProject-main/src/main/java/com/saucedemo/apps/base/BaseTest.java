package com.saucedemo.apps.base;

import com.saucedemo.apps.controller.AppiumDriverManager;
import com.saucedemo.apps.controller.AppiumServiceManager;
import com.saucedemo.apps.utils.Constants;
import com.saucedemo.apps.utils.JsonUtils;
import com.saucedemo.apps.utils.PlatformType;
import com.saucedemo.apps.utils.PropertyUtils;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.appmanagement.ApplicationState;
import io.appium.java_client.ios.IOSDriver;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.IOException;
import java.net.MalformedURLException;

public abstract class BaseTest {

    @BeforeTest
    @Parameters({"profile", "port"})
    public void suiteSetup(@Optional String profile, @Optional String port) {
        try {
            loadTestConfiguration(profile, port);
            AppiumServiceManager.startAppiumService();
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    @BeforeMethod
    public void testSetup() {
        try {
            AppiumDriverManager.getDriver();
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }
    }

    @AfterMethod
    public void testTeardown() {
        terminateApp();
        AppiumDriverManager.killDriver();
    }

    @AfterTest
    public void suiteTeardown() {
        AppiumServiceManager.stopAppiumService();
    }

    private void terminateApp() {
        try {
            if (Constants.get().PLATFORM_TYPE == PlatformType.ANDROID) {
                if (((AndroidDriver)AppiumDriverManager.getDriver()).queryAppState(Constants.get().PKGNAME) != ApplicationState.NOT_RUNNING)
                    ((AndroidDriver)AppiumDriverManager.getDriver()).terminateApp(Constants.get().PKGNAME);
            } else {
                if (((IOSDriver)AppiumDriverManager.getDriver()).queryAppState(Constants.get().BUNDLEID) != ApplicationState.NOT_RUNNING)
                    ((IOSDriver)AppiumDriverManager.getDriver()).terminateApp(Constants.get().BUNDLEID);
            }
            uninstallApp();
        } catch (RuntimeException | MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

    private void uninstallApp() throws MalformedURLException {
        if (Constants.get().PLATFORM_TYPE == PlatformType.ANDROID) {
            ((AndroidDriver)AppiumDriverManager.getDriver()).removeApp(Constants.get().PKGNAME);
        } else {
            ((IOSDriver)AppiumDriverManager.getDriver()).removeApp(Constants.get().BUNDLEID);
        }
    }

    private void loadTestConfiguration(String profileFromXml, String portFromXml) throws IOException {
        PropertyUtils.loadConfigProperties();

        if (profileFromXml != null) {
            Constants.get().DEVICE_PROFILE = profileFromXml;
        }
        if (portFromXml != null) {
            Constants.get().APPIUM_SERVER_PORT = Integer.parseInt(portFromXml);
        }

        JsonUtils.loadDeviceProfile(Constants.get().DEVICE_PROFILE);
    }
}
