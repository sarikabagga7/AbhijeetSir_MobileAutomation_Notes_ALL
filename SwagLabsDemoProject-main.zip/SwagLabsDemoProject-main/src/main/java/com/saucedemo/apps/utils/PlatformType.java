package com.saucedemo.apps.utils;

public enum PlatformType {
    ANDROID,
    IOS
}
